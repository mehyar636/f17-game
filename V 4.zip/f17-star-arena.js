/* ============================================================
   F17 STAR ARENA — v4 JavaScript
   Architecture:
   - Single canvas, fits viewport via CSS (100% width/height)
   - Pitch is a logical 1280x720 coordinate space
   - Canvas pixels = real screen size × DPR
   - Scenes own their own setup/update/draw
   - All tuning in CONFIG table
   ============================================================ */

'use strict';

const $ = (id) => document.getElementById(id);

// ============================================================
// CONFIG — central tuning for all gameplay numbers
// ============================================================
const CONFIG = {
  // Logical pitch coordinates
  pitch: { w: 1280, h: 720 },

  // Player physics
  player: {
    radius: 22,
    moveSpeed: 240,        // px/sec when joystick fully tilted
    dashSpeed: 480,        // px/sec during dash
    dashDuration: 0.45,    // seconds of dash
    dashCooldown: 1.4,     // seconds before dash usable again
    feintDuration: 0.5,
    feintCooldown: 1.2,
  },

  // Ball physics
  ball: {
    radius: 14,
    friction: 0.992,       // per frame at 60fps (≈0.6/sec)
    pickupRadius: 56,
    magnetRadius: 120,     // SHOOT button auto-pickup distance
    autoReturnDelay: 1.5,  // seconds before loose ball returns
    minSlowSpeed: 80,      // ball speed below this counts as "slow"
  },

  // Shot speeds (base + power × multiplier)
  shot: {
    arenaBase: 850,
    penaltyBase: 950,
    crossingBase: 600,
    powerMult: 400,
    minPower: 0.4,
    maxPower: 1.0,
  },

  // Goal
  goal: { w: 16, h: 220 },

  // Difficulty modifiers
  // Easy: forgiving — kid wins easily, builds confidence
  // Medium: balanced — challenging but fair
  // Hard: tough — real test, fewer goals, faster everything
  difficulty: {
    easy:   { keeperReact: 0.60, keeperRead: 0.20, defSpeed: 1.10, energyDrain: 0.20, label: 'ROOKIE',  shotPowerBoost: 1.30, defenderTackleRange: 0.85 },
    medium: { keeperReact: 0.32, keeperRead: 0.50, defSpeed: 1.45, energyDrain: 0.65, label: 'PRO',     shotPowerBoost: 1.05, defenderTackleRange: 1.05 },
    hard:   { keeperReact: 0.18, keeperRead: 0.75, defSpeed: 1.75, energyDrain: 1.10, label: 'LEGEND',  shotPowerBoost: 0.95, defenderTackleRange: 1.25 },
  },

  // Star rating thresholds
  stars: {
    perfectEnergyMin: 75,    // need 75%+ energy for 3 stars
    perfectTimeMin: 0.3,     // need 30%+ time remaining
    goodEnergyMin: 50,
  },

  // Free Kick Studio shot spots (player position; ball is +30 in front)
  // pitch is 1280×720, goal at x=1242 right edge
  shotSpots: {
    'close-c': { x: 1010, y: 360,  label: 'CLOSE • CENTER',     dist: '6m'  },
    'close-l': { x: 1010, y: 240,  label: 'CLOSE • LEFT',       dist: '6m'  },
    'close-r': { x: 1010, y: 480,  label: 'CLOSE • RIGHT',      dist: '6m'  },
    'mid-c':   { x: 880,  y: 360,  label: 'MID • CENTER (18m)', dist: '18m' },
    'mid-l':   { x: 880,  y: 200,  label: 'MID • LEFT WING',    dist: '18m' },
    'mid-r':   { x: 880,  y: 520,  label: 'MID • RIGHT WING',   dist: '18m' },
    'far-c':   { x: 720,  y: 360,  label: 'FAR • CENTER (30m)', dist: '30m' },
    'far-l':   { x: 720,  y: 180,  label: 'FAR • LEFT WING',    dist: '30m' },
    'far-r':   { x: 720,  y: 540,  label: 'FAR • RIGHT WING',   dist: '30m' },
  },

  // Levels per mode
  levels: {
    arena: [
      { name: 'WARM-UP',     goals: 2, defenders: 1, time: 0   /* free play */, coach: 'Score 2 goals to win!' },
      { name: 'TURNING UP',  goals: 3, defenders: 2, time: 0,   coach: 'Use DASH to beat defenders!' },
      { name: 'STAR PLAYER', goals: 3, defenders: 3, time: 180, coach: 'Aim for the corners!' },
    ],
    // FREE KICK STUDIO: 3 spots × 3 shots = 9 attempts per level
    penalty: [
      { name: 'WARMUP', goals: 2, shots: 9, spots: ['close-c', 'close-l', 'close-r'], coach: 'Aim with joystick. Try the corners!' },
      { name: 'STUDIO', goals: 3, shots: 9, spots: ['mid-c', 'mid-l', 'mid-r'],     coach: 'Wing shots auto-curve! Use power for far corners.' },
      { name: 'MASTER', goals: 4, shots: 9, spots: ['far-c', 'mid-l', 'far-r'],     coach: 'Mix corners! Keeper learns your pattern!' },
    ],
    crossing: [
      { name: 'WING DEBUT',   attacks: 2, time: 0,   coach: 'DASH past the fullback, then CROSS or SHOOT!' },
      { name: 'WING STAR',    attacks: 3, time: 0,   coach: 'Pick CROSS for header goals or SHOOT for top-corner!' },
      { name: 'WING MAESTRO', attacks: 4, time: 150, coach: 'Mix it up — keep the keeper guessing!' },
    ],
    boss: [
      { name: 'COURSE 1', gates: 5, defenders: 0, time: 0,   coach: 'Run through the numbered gates in order, then SHOOT!' },
      { name: 'COURSE 2', gates: 6, defenders: 1, time: 0,   coach: 'Avoid the defender — collect all gates, then score!' },
      { name: 'COURSE 3', gates: 7, defenders: 2, time: 120, coach: 'Master the course — DASH past defenders!' },
    ],
  },

  // Scoring
  combo: {
    bonusFor3: 2,    // 2x at 3-streak
    bonusFor5: 3,    // 3x at 5-streak
  },

  // Energy
  energyHit: {
    interceptArena: 8,
    bossBlock: 18,
    defenderBump: 6,
  },

  // Time
  freePlayMarker: 0,  // levels with time === 0 = free play
};

// ============================================================
// SAVE — fresh schema for v4
// ============================================================
const SAVE_KEY = 'f17_star_arena_v4';

const Save = {
  data: {
    version: 4,
    stars: 0, goals: 0, levels: 0,
    modeStars: { arena: 0, penalty: 0, crossing: 0, boss: 0 },
    sound: true, difficulty: 'easy',
    achievements: {},
    bestCombo: 0,
    topCornerGoals: 0,
    perfectLevels: 0,
  },
  load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.version === 4) Object.assign(this.data, parsed);
      }
    } catch (e) {}
  },
  write() {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(this.data)); } catch (e) {}
  },
  reset() {
    Object.assign(this.data, {
      stars: 0, goals: 0, levels: 0,
      modeStars: { arena: 0, penalty: 0, crossing: 0, boss: 0 },
      achievements: {}, bestCombo: 0, topCornerGoals: 0, perfectLevels: 0,
      completedLevels: {},
    });
    this.write();
  },
  addLevelComplete(mode, levelIdx, stars) {
    const prev = this.data.modeStars[mode] || 0;
    if (stars > prev) {
      this.data.stars += (stars - prev);
      this.data.modeStars[mode] = stars;
    }
    // Track unique level completions
    this.data.completedLevels = this.data.completedLevels || {};
    const key = mode + ':' + levelIdx;
    if (!this.data.completedLevels[key] || stars > this.data.completedLevels[key]) {
      this.data.completedLevels[key] = stars;
    }
    // Single source of truth: count unique level keys
    this.data.levels = Object.keys(this.data.completedLevels).length;
    if (stars === 3) this.data.perfectLevels++;
    this.write();
  },
  addGoal() { this.data.goals++; this.write(); },
  unlockAchievement(id) {
    if (this.data.achievements[id]) return false;
    this.data.achievements[id] = Date.now();
    this.write();
    return true;
  },
};
Save.load();

// ============================================================
// ACHIEVEMENTS
// ============================================================
const ACHIEVEMENTS = {
  first_goal:    { name: 'FIRST GOAL!',         icon: '⚽', desc: 'Score your first goal' },
  hat_trick:     { name: 'HAT-TRICK HERO',      icon: '🎩', desc: '3 goals in a row' },
  on_fire:       { name: 'ON FIRE!',            icon: '🔥', desc: '5 goals in a row' },
  top_corner_5:  { name: 'CORNER SPECIALIST',   icon: '🎯', desc: 'Score 5 top-corner goals' },
  goal_10:       { name: 'STRIKER',             icon: '⭐', desc: '10 career goals' },
  goal_50:       { name: 'GOAL MACHINE',        icon: '💎', desc: '50 career goals' },
  goal_100:      { name: 'LEGEND',              icon: '👑', desc: '100 career goals' },
  perfect_level: { name: '3-STAR PERFORMANCE',  icon: '✨', desc: 'Earn 3 stars on a level' },
  all_modes:     { name: 'COMPLETE PLAYER',     icon: '🏆', desc: 'Win in every mode' },
  beat_legend:   { name: 'LEGEND SLAYER',       icon: '🥇', desc: 'Win on Legend difficulty' },
};

function checkAchievements(event, data) {
  const unlocks = [];
  if (event === 'goal') {
    if (Save.data.goals === 1) unlocks.push('first_goal');
    if (Save.data.goals === 10) unlocks.push('goal_10');
    if (Save.data.goals === 50) unlocks.push('goal_50');
    if (Save.data.goals === 100) unlocks.push('goal_100');
    if (data.combo === 3) unlocks.push('hat_trick');
    if (data.combo === 5) unlocks.push('on_fire');
    if (data.isTopCorner) {
      Save.data.topCornerGoals = (Save.data.topCornerGoals || 0) + 1;
      if (Save.data.topCornerGoals === 5) unlocks.push('top_corner_5');
      Save.write();
    }
  }
  if (event === 'level') {
    if (data.stars === 3) unlocks.push('perfect_level');
    if (data.diff === 'hard') unlocks.push('beat_legend');
    const won = Object.values(Save.data.modeStars).every(s => s > 0);
    if (won) unlocks.push('all_modes');
  }
  unlocks.forEach((id, i) => {
    if (Save.unlockAchievement(id)) {
      setTimeout(() => showAchievement(id), 1500 + i * 1800);
    }
  });
}

function showAchievement(id) {
  const a = ACHIEVEMENTS[id];
  if (!a) return;
  Audio.star();
  let el = document.querySelector('.achievement-popup');
  if (!el) {
    el = document.createElement('div');
    el.className = 'achievement-popup';
    document.body.appendChild(el);
  }
  el.innerHTML = `
    <div class="ach-popup-icon">${a.icon}</div>
    <div class="ach-popup-text">
      <div class="ach-popup-tag">UNLOCKED</div>
      <div class="ach-popup-name">${a.name}</div>
      <div class="ach-popup-desc">${a.desc}</div>
    </div>
  `;
  el.classList.remove('show');
  void el.offsetWidth;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 3500);
}

// ============================================================
// AUDIO — procedural, layered
// ============================================================
const Audio = {
  ctx: null,
  enabled: Save.data.sound !== false,
  _ambient: null,

  init() {
    if (this.ctx) {
      // Resume if suspended (iOS Safari)
      if (this.ctx.state === 'suspended') {
        try { this.ctx.resume(); } catch (e) {}
      }
      return;
    }
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      // iOS Safari: must resume after creation in user gesture
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
    } catch (e) {}
  },
  beep(freq, dur, type = 'sine', vol = 0.1) {
    if (!this.enabled || !this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, t);
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(vol, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      osc.connect(g).connect(this.ctx.destination);
      osc.start(t);
      osc.stop(t + dur);
    } catch (e) {}
  },
  sweep(f1, f2, dur, type = 'sine', vol = 0.1) {
    if (!this.enabled || !this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(f1, t);
      osc.frequency.exponentialRampToValueAtTime(f2, t + dur);
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(vol, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      osc.connect(g).connect(this.ctx.destination);
      osc.start(t);
      osc.stop(t + dur);
    } catch (e) {}
  },
  noise(vol, dur, freq = 800) {
    if (!this.enabled || !this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const buf = this.ctx.createBuffer(1, this.ctx.sampleRate * dur, this.ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1);
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = freq;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      src.connect(filter).connect(g).connect(this.ctx.destination);
      src.start(t);
    } catch (e) {}
  },
  toggle() {
    this.enabled = !this.enabled;
    Save.data.sound = this.enabled;
    Save.write();
    if (this.enabled) { this.startAmbient(); this.buttonTap(); }
    else { this.stopAmbient(); }
  },
  // Game sounds
  kick() { this.beep(80, 0.06, 'sine', 0.18); this.sweep(220, 60, 0.12, 'square', 0.14); this.noise(0.07, 0.05, 1200); },
  goal() {
    this.sweep(440, 880, 0.1, 'square', 0.15);
    setTimeout(() => this.sweep(660, 1100, 0.14, 'square', 0.15), 90);
    setTimeout(() => this.sweep(880, 1320, 0.2, 'square', 0.13), 220);
    this.beep(110, 0.3, 'sine', 0.13);
    setTimeout(() => this.noise(0.4, 0.04, 1200), 200);
    setTimeout(() => this.noise(0.7, 0.08, 1800), 350);
  },
  save() { this.beep(180, 0.15, 'sawtooth', 0.11); this.sweep(800, 200, 0.2, 'sawtooth', 0.09); },
  miss() { this.beep(220, 0.2, 'sine', 0.08); },
  star() { this.beep(880, 0.04, 'sine', 0.07); setTimeout(() => this.beep(1320, 0.06, 'sine', 0.08), 30); setTimeout(() => this.beep(1760, 0.06, 'sine', 0.07), 70); },
  hit() { this.noise(0.13, 0.1, 400); this.beep(80, 0.1, 'sawtooth', 0.09); },
  whistle() { this.sweep(1800, 2400, 0.15, 'square', 0.07); setTimeout(() => this.sweep(2200, 1900, 0.18, 'square', 0.07), 200); },
  buttonTap() { this.beep(1100, 0.03, 'sine', 0.05); },
  countdown() { this.beep(660, 0.08, 'sine', 0.1); },
  feint() { this.sweep(880, 440, 0.08, 'sine', 0.09); this.noise(0.07, 0.04, 2000); },
  perfect() {
    this.beep(1320, 0.05, 'sine', 0.09);
    setTimeout(() => this.beep(1760, 0.05, 'sine', 0.09), 50);
    setTimeout(() => this.beep(2640, 0.1, 'sine', 0.09), 100);
    setTimeout(() => this.beep(3520, 0.15, 'sine', 0.07), 180);
  },
  combo(level) {
    const base = 440 + level * 110;
    this.beep(base, 0.06, 'sine', 0.07);
    this.beep(base * 1.5, 0.08, 'sine', 0.07);
  },
  dash() { this.sweep(140, 320, 0.18, 'sawtooth', 0.08); this.noise(0.08, 0.04, 600); },

  startAmbient() {
    if (!this.enabled || !this.ctx || this._ambient) return;
    try {
      const t = this.ctx.currentTime;
      const buf = this.ctx.createBuffer(1, this.ctx.sampleRate * 2, this.ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * 0.5;
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 380;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(0.035, t + 1.5);
      src.connect(filter).connect(g).connect(this.ctx.destination);
      src.start(t);
      this._ambient = { src, gain: g };
    } catch (e) {}
  },
  stopAmbient() {
    if (!this._ambient) return;
    try {
      const t = this.ctx.currentTime;
      this._ambient.gain.gain.linearRampToValueAtTime(0, t + 0.3);
      const node = this._ambient;
      setTimeout(() => { try { node.src.stop(); } catch(e){} }, 400);
    } catch(e){}
    this._ambient = null;
  },
};

// ============================================================
// HELPERS
// ============================================================
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const lerp = (a, b, t) => a + (b - a) * t;
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const rand = (a, b) => a + Math.random() * (b - a);
const randInt = (a, b) => Math.floor(rand(a, b + 1));
const angleTo = (from, to) => Math.atan2(to.y - from.y, to.x - from.x);

function hapticPattern(p) { try { if (navigator.vibrate) navigator.vibrate(p); } catch(e){} }

// Round rect helper
function roundRect(ctx, x, y, w, h, r, fill = true, stroke = false) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

// ============================================================
// SPRITES
// ============================================================
const SPRITES = {
  player: new Image(),
  opp: new Image(),
};
SPRITES.player.src = 'assets/f17-sprite-sheet.png';
SPRITES.opp.src = 'assets/opponents-sprite-sheet.png';

const FRAME_PLAYER = { IDLE: 0, RUN1: 1, RUN2: 2, KICK: 3, CELEBRATE: 4 };
const FRAME_OPP = { DEF_STAND: 0, DEF_RUN: 1, GK_READY: 2, GK_DIVE: 3 };

function drawSprite(img, frameIdx, totalFrames, x, y, w, h, flip = false) {
  if (!img.complete || !img.naturalWidth) {
    // Fallback box
    ctx.fillStyle = '#54d9ff';
    ctx.fillRect(x - w/2, y - h, w, h);
    return;
  }
  const sw = img.naturalWidth / totalFrames;
  const sh = img.naturalHeight;
  ctx.save();
  if (flip) {
    ctx.translate(x, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(img, sw * frameIdx, 0, sw, sh, -w/2, y - h, w, h);
  } else {
    ctx.drawImage(img, sw * frameIdx, 0, sw, sh, x - w/2, y - h, w, h);
  }
  ctx.restore();
}

// ============================================================
// CANVAS / VIEW — proper viewport handling
// ============================================================
const canvas = $('canvas');
const ctx = canvas.getContext('2d');

let view = {
  scale: 1,        // pitch units → screen pixels
  offsetX: 0,
  offsetY: 0,
  screenW: 0,
  screenH: 0,
  dpr: 1,
};

function resizeCanvas() {
  const dpr = Math.min(1.5, window.devicePixelRatio || 1);  // capped for perf
  const sw = window.innerWidth;
  const sh = window.innerHeight;

  canvas.width = Math.round(sw * dpr);
  canvas.height = Math.round(sh * dpr);
  // CSS already handles 100% sizing — no inline style needed

  view.screenW = sw;
  view.screenH = sh;
  view.dpr = dpr;

  // Aspect ratios
  const scaleX = sw / CONFIG.pitch.w;
  const scaleY = sh / CONFIG.pitch.h;
  const fillScale = Math.max(scaleX, scaleY);  // fills screen, may crop pitch
  const fitScale = Math.min(scaleX, scaleY);   // shows full pitch, may letterbox

  const isPortrait = sh > sw;
  const isMobile = sw < 900;

  if (isPortrait && isMobile) {
    showRotate(true);
    view.scale = fitScale;
    view.offsetX = (sw - CONFIG.pitch.w * view.scale) / 2;
    view.offsetY = (sh - CONFIG.pitch.h * view.scale) / 2;
  } else {
    showRotate(false);
    // Always fit fully — letterbox bars on whichever axis doesn't match aspect.
    // The pitch dimensions (1024×640) are tuned to feel close to landscape mobile,
    // so letterbox is minimal on most devices.
    view.scale = fitScale;
    const scaledPitchW = CONFIG.pitch.w * view.scale;
    const scaledPitchH = CONFIG.pitch.h * view.scale;
    view.offsetX = (sw - scaledPitchW) / 2;
    view.offsetY = (sh - scaledPitchH) / 2;
  }
}

function showRotate(show) {
  const el = $('rotateOverlay');
  el.hidden = !show;
}

function applyView() {
  ctx.setTransform(view.dpr, 0, 0, view.dpr, 0, 0);
  ctx.translate(view.offsetX, view.offsetY);
  ctx.scale(view.scale, view.scale);
}

window.addEventListener('resize', resizeCanvas);
window.addEventListener('orientationchange', () => setTimeout(resizeCanvas, 200));

// Auto-pause when tab is backgrounded (kid switches apps, locks screen, etc)
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    if (Scene.current && Scene.current.G && Scene.current.G.running && !Scene.current.G.paused) {
      Scene.current.G.paused = true;
      const overlay = document.getElementById('pauseOverlay');
      if (overlay) overlay.hidden = false;
    }
    // Also pause audio
    if (Audio.ctx && Audio.ctx.state === 'running') {
      try { Audio.ctx.suspend(); } catch (e) {}
    }
  } else {
    // Resume audio context — user must explicitly click resume to unpause game
    if (Audio.ctx && Audio.ctx.state === 'suspended') {
      try { Audio.ctx.resume(); } catch (e) {}
    }
  }
});

// ============================================================
// INPUT
// ============================================================
const Input = {
  joy: { x: 0, y: 0, active: false, id: null },
  shootHeld: false,
};

const joystickEl = $('joystick');
const joyStickEl = $('joyStick');
const shootBtn = $('shootBtn');
const dashBtn = $('dashBtn');
const feintBtn = $('feintBtn');

function joystickPoint(e) {
  const r = joystickEl.getBoundingClientRect();
  const cx = r.left + r.width / 2;
  const cy = r.top + r.height / 2;
  let x = (e.clientX - cx) / (r.width / 2);
  let y = (e.clientY - cy) / (r.height / 2);
  const len = Math.hypot(x, y);
  if (len > 1) { x /= len; y /= len; }
  Input.joy.x = x;
  Input.joy.y = y;
  joyStickEl.style.transform = `translate(calc(-50% + ${x * 30}px), calc(-50% + ${y * 30}px))`;
}

joystickEl.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  Audio.init();
  Input.joy.active = true;
  Input.joy.id = e.pointerId;
  joystickEl.setPointerCapture(e.pointerId);
  joystickPoint(e);
});
joystickEl.addEventListener('pointermove', (e) => {
  if (Input.joy.active && e.pointerId === Input.joy.id) joystickPoint(e);
});
function joystickReset() {
  Input.joy = { x: 0, y: 0, active: false, id: null };
  joyStickEl.style.transform = 'translate(-50%, -50%)';
}
joystickEl.addEventListener('pointerup', joystickReset);
joystickEl.addEventListener('pointercancel', joystickReset);

shootBtn.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  Audio.init();
  Input.shootHeld = true;
  Scene.current.onShootDown && Scene.current.onShootDown();
});
shootBtn.addEventListener('pointerup', (e) => {
  e.preventDefault();
  Input.shootHeld = false;
  Scene.current.onShootUp && Scene.current.onShootUp();
});
shootBtn.addEventListener('pointercancel', () => {
  Input.shootHeld = false;
  Scene.current.onShootUp && Scene.current.onShootUp();
});

dashBtn.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  Audio.init();
  Scene.current.onDash && Scene.current.onDash();
});

feintBtn.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  Audio.init();
  Scene.current.onFeint && Scene.current.onFeint();
});

// Keyboard for desktop
window.addEventListener('keydown', (e) => {
  if (e.key === ' ' && !e.repeat) {
    e.preventDefault();
    Input.shootHeld = true;
    Scene.current.onShootDown && Scene.current.onShootDown();
  }
  if (e.key === 'Shift') Scene.current.onDash && Scene.current.onDash();
  if (e.key.toLowerCase() === 'f') Scene.current.onFeint && Scene.current.onFeint();
  if (e.key === 'Escape') Scene.current.onPause && Scene.current.onPause();
});
window.addEventListener('keyup', (e) => {
  if (e.key === ' ') {
    Input.shootHeld = false;
    Scene.current.onShootUp && Scene.current.onShootUp();
  }
});
window.addEventListener('keydown', (e) => {
  // WASD/arrows for joystick simulation on desktop
  let dx = 0, dy = 0;
  if (['ArrowLeft', 'a', 'A'].includes(e.key)) dx = -1;
  if (['ArrowRight', 'd', 'D'].includes(e.key)) dx = 1;
  if (['ArrowUp', 'w', 'W'].includes(e.key)) dy = -1;
  if (['ArrowDown', 's', 'S'].includes(e.key)) dy = 1;
  if (dx || dy) { Input.joy.x = dx; Input.joy.y = dy; }
});
window.addEventListener('keyup', (e) => {
  if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','a','A','d','D','w','W','s','S'].includes(e.key)) {
    Input.joy.x = 0; Input.joy.y = 0;
  }
});

// Prevent canvas scroll
document.addEventListener('touchmove', (e) => {
  if (Scene.current && Scene.current.name !== 'home') e.preventDefault();
}, { passive: false });

// ============================================================
// SCENE MANAGER
// ============================================================
const Scene = {
  current: null,
  scenes: {},
  raf: 0,
  lastTime: 0,

  register(name, scene) {
    scene.name = name;
    this.scenes[name] = scene;
  },

  switch(name, params = {}) {
    if (this.current && this.current.exit) this.current.exit();
    this.current = this.scenes[name];
    this.current.params = params;
    if (this.current.enter) this.current.enter(params);
    if (!this.raf) this.start();
  },

  start() {
    this.lastTime = performance.now();
    const loop = (now) => {
      const dt = Math.min(0.05, (now - this.lastTime) / 1000);
      this.lastTime = now;
      if (this.current && this.current.update) this.current.update(dt);
      if (this.current && this.current.draw) this.current.draw();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  },
};

// ============================================================
// HOME SCENE
// ============================================================
Scene.register('home', {
  enter() {
    $('home').classList.add('active');
    $('game').classList.remove('active');
    Audio.stopAmbient();
    refreshHome();
  },
  exit() {
    $('home').classList.remove('active');
  },
  update() {},
  draw() {},
});

function refreshHome() {
  $('careerStars').textContent = Save.data.stars;
  $('careerGoals').textContent = Save.data.goals;
  $('careerLevels').textContent = Save.data.levels;

  // Mode stars
  ['arena', 'penalty', 'crossing', 'boss'].forEach((mode) => {
    const el = document.querySelector(`[data-mode-stars="${mode}"]`);
    if (el) {
      const s = Save.data.modeStars[mode] || 0;
      el.textContent = '★'.repeat(s) + '☆'.repeat(3 - s);
    }
  });

  // Sound
  $('soundOn').hidden = !Audio.enabled;
  $('soundOff').hidden = Audio.enabled;

  // Difficulty
  document.querySelectorAll('.diff-btn').forEach((b) => {
    b.classList.toggle('active', b.dataset.diff === Save.data.difficulty);
  });

  // Achievements
  const total = Object.keys(ACHIEVEMENTS).length;
  const unlocked = Object.keys(Save.data.achievements || {}).length;
  $('achCount').textContent = `${unlocked}/${total}`;
  const row = $('achRow');
  row.innerHTML = Object.entries(ACHIEVEMENTS).map(([id, a]) => {
    const u = !!Save.data.achievements?.[id];
    return `<div class="ach-pill ${u ? 'unlocked' : ''}" title="${a.name}: ${a.desc}">${a.icon}</div>`;
  }).join('');
}

// Mode card clicks
document.querySelectorAll('.mode-card').forEach((card) => {
  card.addEventListener('click', () => {
    Audio.init(); Audio.buttonTap();
    showModeIntro(card.dataset.mode);
  });
});
// Difficulty
document.querySelectorAll('.diff-btn').forEach((b) => {
  b.addEventListener('click', () => {
    Audio.buttonTap();
    Save.data.difficulty = b.dataset.diff;
    Save.write();
    refreshHome();
  });
});
// Sound
$('soundBtn').addEventListener('click', () => {
  Audio.init();
  Audio.toggle();
  refreshHome();
});
// Reset
$('resetBtn').addEventListener('click', () => {
  if (confirm('Reset all progress?')) { Save.reset(); refreshHome(); }
});
// Help
$('helpBtn').addEventListener('click', () => showHelp());

// ============================================================
// MODAL
// ============================================================
const modal = $('modal');
const modalPanel = $('modalPanel');

function showModal(html) {
  modalPanel.innerHTML = html;
  modal.hidden = false;
}
function hideModal() { modal.hidden = true; }

function showHelp() {
  showModal(`
    <div class="modal-icon">⚽</div>
    <h2>HOW TO PLAY</h2>
    <div class="intro-steps">
      <div class="intro-step"><div class="step-num">1</div><div class="step-icon">🕹️</div><div class="step-text">Joystick (left) moves Faisal. Aim by holding it while charging.</div></div>
      <div class="intro-step"><div class="step-num">2</div><div class="step-icon">⚽</div><div class="step-text">Hold red SHOOT button to charge power. Release to kick!</div></div>
      <div class="intro-step"><div class="step-num">3</div><div class="step-icon">⚡</div><div class="step-text">Tap yellow DASH for a speed burst — beats defenders!</div></div>
      <div class="intro-step"><div class="step-num">4</div><div class="step-icon">↗️</div><div class="step-text">WING ATTACK: DASH past the fullback, then tap CROSS or SHOOT</div></div>
      <div class="intro-step"><div class="step-num">5</div><div class="step-icon">🚩</div><div class="step-text">SKILLS COURSE: run through numbered gates in order, then SHOOT at goal</div></div>
    </div>
    <button class="btn-primary" id="mClose">LET'S PLAY!</button>
  `);
  $('mClose').onclick = () => { Audio.buttonTap(); hideModal(); };
}

function showModeIntro(mode) {
  const cfg = CONFIG.levels[mode];
  const stars = Save.data.modeStars[mode] || 0;
  const modeNames = { arena: 'STAR ARENA', penalty: 'FREE KICK STUDIO', crossing: 'WING ATTACK', boss: 'SKILLS COURSE' };
  const modeIcons = { arena: '⚽', penalty: '🎯', crossing: '↗️', boss: '⚡' };

  const instructions = {
    arena: [
      { icon: '🕹️', text: 'Move Faisal with the joystick' },
      { icon: '⚽', text: 'Hold SHOOT to charge — joystick UP/DOWN aims!' },
      { icon: '↶', text: 'Shoot from the wings to bend the ball into the goal' },
      { icon: '⚡', text: 'Tap DASH for speed bursts past defenders' },
      { icon: '🏆', text: `Score ${cfg[0].goals} goals to win` },
    ],
    penalty: [
      { icon: '🎯', text: 'Take 9 free kicks from 3 different spots' },
      { icon: '🕹️', text: 'Joystick UP/DOWN aims high or low corners' },
      { icon: '↶', text: 'Wing shots auto-curve toward goal — like real wingers!' },
      { icon: '💪', text: 'Hold SHOOT longer = more power' },
      { icon: '👀', text: 'Keeper LEARNS — never repeat the same corner!' },
      { icon: '🏆', text: `Score ${cfg[0].goals}/9 to win level` },
    ],
    crossing: [
      { icon: '⚡', text: 'PHASE 1 — DASH past the fullback on the wing' },
      { icon: '🏃', text: 'PHASE 2 — Run to the byline (highlighted zone)' },
      { icon: '🤔', text: 'PHASE 3 — DECIDE: CROSS button or SHOOT yourself' },
      { icon: '🎯', text: 'Cross = teammate scores from header' },
      { icon: '⚽', text: 'Shoot = curving wing strike into far corner' },
      { icon: '🏆', text: `Complete ${cfg[0].attacks} attacks to win` },
    ],
    boss: [
      { icon: '🎯', text: 'Run through numbered GATES in order: 1 → 2 → 3...' },
      { icon: '🔵', text: 'Active gate glows BLUE. Touch it to collect.' },
      { icon: '⚽', text: 'After all gates collected, run to goal and SHOOT' },
      { icon: '⚡', text: 'Tap DASH (yellow) for speed bursts past defenders' },
      { icon: '🏆', text: `Collect all ${cfg[0].gates} gates and score to win!` },
    ],
  }[mode];

  showModal(`
    <div class="modal-icon">${modeIcons[mode]}</div>
    <h2>${modeNames[mode]}</h2>
    <div class="modal-stars">${[0,1,2].map(i => `<span class="star ${i < stars ? 'earned' : ''}">★</span>`).join('')}</div>
    <div class="intro-steps">
      ${instructions.map((s, i) => `
        <div class="intro-step">
          <div class="step-num">${i + 1}</div>
          <div class="step-icon">${s.icon}</div>
          <div class="step-text">${s.text}</div>
        </div>
      `).join('')}
    </div>
    <button class="btn-primary" id="mStart">▶ START PLAYING</button>
    <button class="btn-secondary" id="mCancel">BACK</button>
  `);
  $('mStart').onclick = () => {
    Audio.buttonTap();
    hideModal();
    startLevel(mode, 0);
  };
  $('mCancel').onclick = () => { Audio.buttonTap(); hideModal(); };
}

// ============================================================
// HUD
// ============================================================
const HUD = {
  set(id, value) { const el = $(id); if (el) el.textContent = value; },
  setEnergy(pct) {
    $('energyFill').style.width = clamp(pct, 0, 100) + '%';
  },
  setCombo(combo) {
    const el = $('comboHud');
    if (combo < 2) { el.hidden = true; return; }
    el.hidden = false;
    el.classList.toggle('hot', combo >= 3);
    el.classList.toggle('fire', combo >= 5);
    const labels = { 2: 'DOUBLE', 3: 'TRIPLE', 4: 'QUAD', 5: 'PENTA', 6: 'HEXA' };
    $('comboLabel').textContent = labels[Math.min(6, combo)] || `${combo}x`;
    $('comboMult').textContent = `x${combo >= 5 ? 3 : combo >= 3 ? 2 : 1}`;
  },
  setCoach(text, duration = 4000) {
    if (!text) { $('coachBubble').hidden = true; return; }
    $('coachText').textContent = text;
    $('coachBubble').hidden = false;
    clearTimeout(this._coachT);
    this._coachT = setTimeout(() => $('coachBubble').hidden = true, duration);
  },
  showToast(text, color = 'gold', duration = 1200) {
    const el = $('toast');
    $('toastText').textContent = text;
    el.className = 'toast' + (color === 'red' ? ' red' : '');
    el.hidden = false;
    clearTimeout(this._toastT);
    this._toastT = setTimeout(() => el.hidden = true, duration);
  },
  setMission(target, text) {
    $('mbTarget').textContent = target;
    $('mbText').textContent = text;
  },
  setScoreboard(home, away, awayLabel, mode, level) {
    $('sbHome').textContent = home;
    $('sbAway').textContent = away;
    $('sbAwayLabel').textContent = awayLabel;
    $('sbMode').textContent = mode;
    $('sbLevel').textContent = level;
  },
  setTimeStyle(remaining) {
    const el = $('sbAway');
    el.classList.toggle('time-low', remaining < 20 && remaining > 10);
    el.classList.toggle('time-critical', remaining > 0 && remaining <= 10);
  },
  showFeintBtn(show) { $('feintBtn').hidden = !show; },
  setFeintLabel(label) {
    const btn = $('feintBtn');
    const lbl = btn.querySelector('.ab-label');
    if (lbl) lbl.textContent = label;
  },
};

// ============================================================
// PITCH RENDERING (shared across game scenes)
// ============================================================
// Cache static pitch (lines, stripes, gradient) to offscreen canvas for perf
let pitchCache = null;
function buildPitchCache() {
  const w = CONFIG.pitch.w;
  const h = CONFIG.pitch.h;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const cx = c.getContext('2d');

  // Thin dark band at very top (subtle stadium hint, not distracting)
  cx.fillStyle = '#02110a';
  cx.fillRect(0, 0, w, 18);

  // Pitch (green) — gradient with stripes — use almost full canvas
  const pitchTop = 18;
  const pitchH = h - pitchTop;
  const grad = cx.createLinearGradient(0, pitchTop, 0, h);
  grad.addColorStop(0, '#1a8a3e');
  grad.addColorStop(1, '#0d6028');
  cx.fillStyle = grad;
  cx.fillRect(0, pitchTop, w, pitchH);
  cx.fillStyle = 'rgba(255,255,255,0.04)';
  for (let i = 0; i < 12; i++) {
    if (i % 2 === 0) cx.fillRect(i * (w / 12), pitchTop, w / 12, pitchH);
  }
  // Lines
  cx.strokeStyle = 'rgba(255,255,255,0.55)';
  cx.lineWidth = 3;
  cx.strokeRect(40, pitchTop + 14, w - 80, pitchH - 28);
  cx.beginPath();
  cx.arc(w/2, pitchTop + pitchH/2, 80, 0, Math.PI*2);
  cx.stroke();
  cx.beginPath();
  cx.moveTo(w/2, pitchTop + 14);
  cx.lineTo(w/2, h - 14);
  cx.stroke();
  cx.strokeRect(w - 240, pitchTop + 90, 200, pitchH - 180);
  cx.strokeRect(w - 100, pitchTop + 170, 60, pitchH - 340);
  cx.strokeRect(40, pitchTop + 90, 200, pitchH - 180);
  cx.strokeRect(40, pitchTop + 170, 60, pitchH - 340);
  cx.fillStyle = 'rgba(255,255,255,0.7)';
  cx.beginPath(); cx.arc(w - 150, pitchTop + pitchH/2, 4, 0, Math.PI*2); cx.fill();
  cx.beginPath(); cx.arc(150, pitchTop + pitchH/2, 4, 0, Math.PI*2); cx.fill();

  pitchCache = c;
}

function drawPitch(t) {
  if (!pitchCache) buildPitchCache();
  // Blit cached static pitch (single fast operation) — no overlay clutter
  ctx.drawImage(pitchCache, 0, 0);
}

// Draw goal at right side
function drawGoal() {
  const g = { x: CONFIG.pitch.w - 38, y: CONFIG.pitch.h / 2, w: CONFIG.goal.w, h: CONFIG.goal.h };
  const top = g.y - g.h/2;
  // Net background
  ctx.fillStyle = 'rgba(255,255,255,0.05)';
  ctx.fillRect(g.x, top, 26, g.h);
  // Net pattern
  ctx.strokeStyle = 'rgba(255,255,255,0.3)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 8; i++) {
    const dy = top + i * (g.h / 8);
    ctx.beginPath();
    ctx.moveTo(g.x, dy);
    ctx.lineTo(g.x + 26, dy + 4);
    ctx.stroke();
  }
  for (let i = 0; i < 6; i++) {
    const dx = g.x + i * (26 / 5);
    ctx.beginPath();
    ctx.moveTo(dx, top);
    ctx.lineTo(dx, top + g.h);
    ctx.stroke();
  }
  // Posts (white)
  ctx.fillStyle = '#fff';
  ctx.fillRect(g.x - 4, top - 4, 8, g.h + 8);  // left post
  ctx.fillRect(g.x - 4, top - 4, 38, 8);       // crossbar
  ctx.fillRect(g.x - 4, top + g.h - 4, 38, 8); // bottom bar
  return g;
}

// Particle system
function makeParticles(x, y, color, count, opts = {}) {
  const out = [];
  for (let i = 0; i < count; i++) {
    out.push({
      x, y,
      vx: rand(-(opts.speed || 200), (opts.speed || 200)),
      vy: rand(-(opts.speed || 200), opts.gravity ? -(opts.speed || 100) : (opts.speed || 200)),
      r: rand(2, opts.maxR || 6),
      color,
      life: rand(0.4, opts.life || 1.0),
      gravity: opts.gravity,
    });
  }
  return out;
}

function updateParticles(arr, dt) {
  return arr.filter((p) => {
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.96;
    p.vy *= 0.96;
    if (p.gravity) p.vy += 600 * dt;
    return p.life > 0;
  });
}

function drawParticles(arr) {
  arr.forEach((p) => {
    ctx.globalAlpha = clamp(p.life, 0, 1);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
}

function drawShadow(x, y, w = 20, h = 6) {
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.beginPath();
  ctx.ellipse(x, y, w, h, 0, 0, Math.PI * 2);
  ctx.fill();
}

// ============================================================
// COMMON GAME STATE BUILDER
// ============================================================
function makeGameState(mode, levelIdx) {
  const cfg = CONFIG.levels[mode][levelIdx];
  return {
    mode,
    levelIdx,
    cfg,
    diff: Save.data.difficulty,
    running: true,
    paused: false,
    countdown: 3,

    score: 0,
    goalsScored: 0,
    energy: 100,
    combo: 0,
    bestCombo: 0,
    timeLeft: cfg.time || 999,
    attemptsUsed: 0,
    // Free Kick Studio
    spotIdx: 0,
    shotsAtSpot: 0,
    // Wing Attack
    attacksCompleted: 0,
    wingPhase: 'beat',
    wingByline: false,
    wingSide: 'right',
    crossDelivered: false,
    // Skills Course
    gateIdx: 0,
    gatesCollected: 0,
    coursePhase: 'gates',  // 'gates' | 'shoot'
    gates: [],

    player: {
      x: 200, y: CONFIG.pitch.h / 2,
      vx: 0, vy: 0,
      r: CONFIG.player.radius,
      facing: 0,
      animTime: 0, runTime: 0,
      kickTime: 0, dashTime: 0, dashCool: 0,
      celebTime: 0, hitTime: 0,
      feintTime: 0, feintCool: 0,
    },

    ball: {
      x: 240, y: CONFIG.pitch.h / 2,
      vx: 0, vy: 0,
      r: CONFIG.ball.radius,
      owner: 'player', // 'player', 'none', 'enemy'
      lastTouch: 'player',
      looseTime: 0,
      spin: 0,
      shotInfo: null,
    },

    keeper: {
      x: CONFIG.pitch.w - 60, y: CONFIG.pitch.h / 2,
      r: 20, animTime: 0,
      reactionTime: 0, committedY: CONFIG.pitch.h / 2,
      shotMemory: [],
      anim: 'ready', diveTime: 0,
    },

    enemies: [],
    teammate: null,
    crossZone: null,

    charge: { active: false, power: 0, aimX: 0, aimY: 0 },

    particles: [],
    shockwaves: [],
    timeScale: 1,
    timeScaleTarget: 1,
    crowdHype: 0,
  };
}

// ============================================================
// SHARED MECHANICS — used by all game scenes
// ============================================================
const Mechanics = {
  updatePlayer(G, dt) {
    const p = G.player;
    const cfg = CONFIG.player;
    p.animTime += dt;
    p.kickTime = Math.max(0, p.kickTime - dt);
    p.celebTime = Math.max(0, p.celebTime - dt);
    p.dashTime = Math.max(0, p.dashTime - dt);
    p.dashCool = Math.max(0, p.dashCool - dt);
    p.hitTime = Math.max(0, p.hitTime - dt);
    p.feintTime = Math.max(0, p.feintTime - dt);
    p.feintCool = Math.max(0, p.feintCool - dt);

    if (G.charge.active) {
      // Update aim
      G.charge.aimX = Input.joy.x;
      G.charge.aimY = Input.joy.y;
      G.charge.power = clamp(G.charge.power + dt * 0.7, 0, 1);
      // Slow movement during charge
      p.vx *= 0.85; p.vy *= 0.85;
      // While charging, always face goal (right)
      p.facing = 0;
    } else if (p.celebTime <= 0) {
      // FREE KICK MODE: player is rooted to the spot — joystick aims, doesn't move
      if (G.mode === 'penalty') {
        p.vx *= 0.5; p.vy *= 0.5;
        p.facing = 0;  // always face goal
        // Joystick is interpreted as AIM PREVIEW — no movement
      } else {
        const speed = p.dashTime > 0 ? cfg.dashSpeed : cfg.moveSpeed;
        const tx = Input.joy.x * speed;
        const ty = Input.joy.y * speed;
        p.vx = lerp(p.vx, tx, dt * 8);
        p.vy = lerp(p.vy, ty, dt * 8);
        if (Math.abs(p.vx) > 5 || Math.abs(p.vy) > 5) {
          p.facing = Math.atan2(p.vy, p.vx);
          p.runTime += dt;
        } else {
          // Idle: face toward goal (right) gradually
          p.facing = lerp(p.facing, 0, dt * 3);
        }
      }
    }

    p.x = clamp(p.x + p.vx * dt, 60, CONFIG.pitch.w - 60);
    p.y = clamp(p.y + p.vy * dt, 100, CONFIG.pitch.h - 40);
  },

  updateBall(G, dt) {
    const b = G.ball;
    const p = G.player;

    if (b.owner === 'player' && p.celebTime <= 0) {
      // Stick to player slightly ahead in facing direction
      const offX = Math.cos(p.facing) * 32;
      const offY = Math.sin(p.facing) * 32;
      b.x = lerp(b.x, p.x + offX, dt * 14);
      b.y = lerp(b.y, p.y + offY, dt * 14);
      b.vx = 0; b.vy = 0;
      b.looseTime = 0;
      return;
    }

    // Spin curve
    if (Math.abs(b.spin) > 0.01) {
      const speed = Math.hypot(b.vx, b.vy);
      if (speed > 0.1) {
        const perpX = -b.vy / speed;
        const perpY = b.vx / speed;
        b.vx += perpX * b.spin * 380 * dt;
        b.vy += perpY * b.spin * 380 * dt;
      }
      b.spin *= 0.985;
    }

    // Position update
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    // Friction
    b.vx *= CONFIG.ball.friction;
    b.vy *= CONFIG.ball.friction;
    // Bounds
    if (b.x < b.r) { b.x = b.r; b.vx *= -0.6; }
    if (b.x > CONFIG.pitch.w - b.r) { b.x = CONFIG.pitch.w - b.r; b.vx *= -0.6; }
    if (b.y < 100) { b.y = 100; b.vy *= -0.6; }
    if (b.y > CONFIG.pitch.h - 40) { b.y = CONFIG.pitch.h - 40; b.vy *= -0.6; }

    // Pickup if close & slow
    if (b.lastTouch !== 'just-shot' && dist(b, p) < CONFIG.ball.pickupRadius && Math.hypot(b.vx, b.vy) < 220 && p.celebTime <= 0) {
      b.owner = 'player';
      b.lastTouch = 'player';
      b.looseTime = 0;
    }

    // Auto-return after delay
    if (b.owner !== 'player' && Math.hypot(b.vx, b.vy) < CONFIG.ball.minSlowSpeed) {
      b.looseTime += dt;
      if (b.looseTime > CONFIG.ball.autoReturnDelay) {
        Mechanics.resetBall(G);
        HUD.setCoach('Ball returned. Try again!', 2500);
      }
    } else {
      b.looseTime = 0;
    }

    // Cool down lastTouch
    if (b.lastTouch === 'just-shot') {
      setTimeout(() => { if (G.ball.lastTouch === 'just-shot') G.ball.lastTouch = 'shot'; }, 350);
    }
  },

  resetBall(G) {
    const p = G.player;
    G.ball.x = p.x + 30;
    G.ball.y = p.y;
    G.ball.vx = 0; G.ball.vy = 0;
    G.ball.spin = 0;
    G.ball.owner = 'player';
    G.ball.lastTouch = 'player';
    G.ball.shotInfo = null;
    G.ball.shotResolved = false;
    G.ball.looseTime = 0;
  },

  updateKeeper(G, dt) {
    const k = G.keeper;
    k.animTime += dt;
    k.diveTime = Math.max(0, k.diveTime - dt);

    // PENALTY mode: keeper anticipates aim during charge
    if (G.mode === 'penalty' && G.charge.active) {
      const diff = CONFIG.difficulty[G.diff];
      const aimY = G.charge.aimY || 0;
      const predictedY = CONFIG.pitch.h / 2 + aimY * CONFIG.goal.h * 0.32;
      const speed = 280 * diff.keeperRead + 80;
      const dy = predictedY - k.y;
      k.y += Math.sign(dy) * Math.min(Math.abs(dy), speed * dt);
      k.y = clamp(k.y, CONFIG.pitch.h/2 - CONFIG.goal.h/2 + 12, CONFIG.pitch.h/2 + CONFIG.goal.h/2 - 12);
      k.anim = 'ready';
      return;
    }

    if (k.reactionTime > 0) {
      k.reactionTime -= dt;
      k.y = CONFIG.pitch.h / 2 + Math.sin(k.animTime * 1.2) * 4;
    } else if (G.ball.shotInfo && G.ball.lastTouch !== 'player') {
      const dy = k.committedY - k.y;
      const diff = CONFIG.difficulty[G.diff];
      const speed = 540 * diff.keeperRead + 260;
      k.y += Math.sign(dy) * Math.min(Math.abs(dy), speed * dt);
      k.anim = 'dive';
    } else {
      // Idle
      k.y = lerp(k.y, CONFIG.pitch.h / 2 + Math.sin(k.animTime * 1.2) * 4, dt * 3);
      k.anim = 'ready';
    }
  },

  updateEnemies(G, dt) {
    const p = G.player;
    G.enemies.forEach((e) => {
      e.animTime += dt;
      e.stun = Math.max(0, e.stun - dt);
      if (e.stun > 0) {
        e.anim = 'stand';
        // Decay velocity to stop
        e.vx *= 0.85; e.vy *= 0.85;
        return;
      }
      if (e.mode === 'boss' || e.mode === 'fullback' || e.mode === 'street') return;
      // Generic defender — calm steering toward ball or player
      const ball = G.ball;
      const ballSpeed = Math.hypot(ball.vx, ball.vy);
      let target;
      let chaseRange = 0;  // distance considered "close enough" — stops chasing inside this

      if (ball.owner === 'none' && ballSpeed > 150) {
        // Ball is loose — predict where it will be
        const predX = ball.x + ball.vx * 0.3;
        const predY = ball.y + ball.vy * 0.3;
        target = { x: predX, y: predY };
        chaseRange = 20;
      } else if (ball.owner === 'player') {
        // ALWAYS chase the player when they have the ball — defenders work as a unit.
        // Different defenders have slightly different roles based on home position:
        //   - Closer to goal → mark the player tightly
        //   - Further from goal → cover space ahead of the player
        const distFromGoal = CONFIG.pitch.w - e.homeX;
        if (distFromGoal < 250) {
          // Goal-side defender: mark player directly
          target = { x: p.x, y: p.y };
          chaseRange = e.r + p.r + 8;
        } else {
          // Midfield defender: cover space slightly ahead of player
          target = { x: p.x + 60, y: p.y };
          chaseRange = e.r + p.r + 14;
        }
      } else {
        // No ball owner and ball not loose → return home briefly
        target = { x: e.homeX, y: e.homeY };
        chaseRange = 12;
      }

      const dx = target.x - e.x;
      const dy = target.y - e.y;
      const d = Math.hypot(dx, dy);

      const diff = CONFIG.difficulty[G.diff];
      const levelSpeedBoost = 1 + (G.levelIdx || 0) * 0.12;  // +12%/level (L1=1.0, L2=1.12, L3=1.24)
      const maxSpeed = 130 * diff.defSpeed * levelSpeedBoost;

      if (d < chaseRange) {
        // Close enough — stop and damp velocity (prevents wobble)
        e.vx *= 0.85;
        e.vy *= 0.85;
      } else {
        // Move toward target — smoothed
        const desiredVx = (dx / d) * maxSpeed;
        const desiredVy = (dy / d) * maxSpeed;
        e.vx = lerp(e.vx, desiredVx, dt * 4);
        e.vy = lerp(e.vy, desiredVy, dt * 4);
      }

      e.x = clamp(e.x + e.vx * dt, 80, CONFIG.pitch.w - 100);
      e.y = clamp(e.y + e.vy * dt, 110, CONFIG.pitch.h - 50);
      e.anim = Math.hypot(e.vx, e.vy) > 30 ? 'run' : 'stand';

      // Tackle — range scales with difficulty
      const diffCfg = CONFIG.difficulty[G.diff];
      const tackleRange = (p.r + e.r) * (diffCfg.defenderTackleRange || 1.0);
      if (G.ball.owner === 'player' && dist(p, e) < tackleRange && p.dashTime <= 0 && (e.tackleCool || 0) <= 0) {
        Mechanics.tackle(G, e);
        e.tackleCool = 1.0;
      }
      e.tackleCool = Math.max(0, (e.tackleCool || 0) - dt);
    });
  },

  tackle(G, e) {
    G.ball.owner = 'none';
    G.ball.lastTouch = 'enemy';
    const ang = angleTo({ x: CONFIG.pitch.w - 60, y: CONFIG.pitch.h / 2 }, e);
    G.ball.vx = Math.cos(ang) * 250;
    G.ball.vy = Math.sin(ang) * 250;
    G.player.hitTime = 0.3;
    G.energy = Math.max(0, G.energy - CONFIG.energyHit.bossBlock * CONFIG.difficulty[G.diff].energyDrain);
    G.combo = 0;
    Audio.hit();
    hapticPattern([60, 40, 60]);
    HUD.showToast('BLOCKED!', 'red', 800);
    HUD.setCoach('Defender stole the ball! Back to start — try again.');
    G.particles.push(...makeParticles(G.player.x, G.player.y, '#ff7e7e', 12));
    // In Arena, reset player to start position after a tackle
    if (G.mode === 'arena') {
      setTimeout(() => { if (G.running) Mechanics.kickoffReset(G); }, 800);
    }
  },

  startCharge(G) {
    if (!G.running || G.countdown > 0) return;
    if (G.player.kickTime > 0 || G.player.celebTime > 0) return;
    if (G.ball.owner !== 'player') {
      // Try to magnet pickup if close
      if (dist(G.ball, G.player) < CONFIG.ball.magnetRadius) {
        G.ball.owner = 'player';
        G.ball.lastTouch = 'player';
        G.ball.vx = 0; G.ball.vy = 0;
        G.ball.spin = 0;
        G.ball.looseTime = 0;
      } else {
        HUD.setCoach('Run to the ball first!');
        return;
      }
    }
    G.charge.active = true;
    G.charge.power = 0.2;
    shootBtn.classList.add('charging');
  },

  releaseCharge(G) {
    if (!G.charge.active) return;
    shootBtn.classList.remove('charging');
    if (G.ball.owner !== 'player') { G.charge.active = false; return; }
    Mechanics.shoot(G);
    G.charge.active = false;
    G.charge.power = 0;
  },

  shoot(G) {
    const charge = G.charge;
    const p = G.player;
    const b = G.ball;
    const power = clamp(charge.power, CONFIG.shot.minPower, CONFIG.shot.maxPower);

    // Base speed by mode
    let speedBase = CONFIG.shot.arenaBase;
    if (G.mode === 'penalty') speedBase = CONFIG.shot.penaltyBase;
    if (G.mode === 'crossing') speedBase = CONFIG.shot.crossingBase;

    // Determine target
    let targetX, targetY;
    if (G.mode === 'crossing') {
      // Cross to teammate based on aim type
      if (G.teammate) {
        targetX = G.teammate.x;
        targetY = G.teammate.y;
      } else {
        targetX = CONFIG.pitch.w - 100;
        targetY = CONFIG.pitch.h / 2;
      }
    } else {
      // Aim at goal with aimY shifting
      targetX = CONFIG.pitch.w - 50;
      targetY = CONFIG.pitch.h / 2 + charge.aimY * (CONFIG.goal.h * 0.45);
    }

    // SPOT-BASED AUTO-CURVE
    // Ball naturally curves toward goal center based on shooter's wing position.
    // Right wing → ball curves LEFT (negative spin)
    // Left wing → ball curves RIGHT (positive spin)
    // Center / penalty → no curve
    // Curve strength scales with distance to goal AND offset from center
    const goalCenterY = CONFIG.pitch.h / 2;
    const offsetFromCenter = b.y - goalCenterY;  // negative = above center, positive = below
    const distFromGoal = (CONFIG.pitch.w - 50) - b.x;
    const distFactor = clamp(distFromGoal / 600, 0, 1);  // farther = more curve potential
    const wingFactor = clamp(Math.abs(offsetFromCenter) / 200, 0, 1);  // wider = more curve
    // Sign: above center curves DOWN toward center; below center curves UP toward center
    const autoCurve = -Math.sign(offsetFromCenter) * 0.7 * distFactor * wingFactor;
    b.spin = autoCurve;

    const dx = targetX - b.x;
    const dy = targetY - b.y;
    const distance = Math.hypot(dx, dy) || 1;
    const diff = CONFIG.difficulty[G.diff];
    const diffPowerBoost = diff.shotPowerBoost || 1.0;
    // LEVEL POWER PROGRESSION: each level -3% shot power (L1=1.0, L2=0.97, L3=0.94)
    // So even Hard L3 still has decent power
    const levelPowerScale = 1.0 - (G.levelIdx * 0.03);
    const totalPowerMult = diffPowerBoost * levelPowerScale;
    const speed = (speedBase + power * CONFIG.shot.powerMult) * totalPowerMult;
    b.vx = (dx / distance) * speed;
    b.vy = (dy / distance) * speed;
    b.owner = 'none';
    b.lastTouch = 'just-shot';
    b.shotResolved = false;

    // Shot info for keeper save (curve makes save harder)
    const corner = Math.abs(charge.aimY) > 0.5;
    b.shotInfo = {
      power, curve: b.spin, corner,
      targetY,
      lane: charge.aimY < -0.3 ? 'high' : charge.aimY > 0.3 ? 'low' : 'middle',
      travelTime: distance / speed,
    };

    // Keeper memory
    G.keeper.shotMemory.push({ y: targetY, q: Mechanics.shotQuadrant(targetY) });
    if (G.keeper.shotMemory.length > 4) G.keeper.shotMemory.shift();

    // Decide keeper dive
    Mechanics.decideKeeperDive(G, targetY);

    p.kickTime = 0.3;
    Audio.kick();
    hapticPattern([20]);
  },

  decideKeeperDive(G, targetY) {
    const k = G.keeper;
    const diff = CONFIG.difficulty[G.diff];
    let baseReact = G.mode === 'penalty' ? diff.keeperReact * 0.35 : diff.keeperReact;
    k.reactionTime = baseReact;

    // Quadrant of incoming shot (1-5: TL, TR, M, BL, BR)
    const quadrant = Mechanics.shotQuadrant(targetY);
    const memory = k.shotMemory;

    // ADAPTIVE LEARNING: as Faisal scores more, GK reads better
    // BUT scale this with difficulty so Easy stays forgiving
    const adaptiveScale = G.diff === 'easy' ? 0.02 : G.diff === 'medium' ? 0.04 : 0.05;
    const adaptiveCap   = G.diff === 'easy' ? 0.12 : G.diff === 'medium' ? 0.20 : 0.28;
    const goalsBonus = Math.min(adaptiveCap, G.goalsScored * adaptiveScale);
    // LEVEL PROGRESSION: GK reads +9% per level above level 1 (noticeable ramp)
    const levelBonus = (G.levelIdx || 0) * 0.09;
    const readChance = clamp(diff.keeperRead + goalsBonus + levelBonus, 0.15, 0.85);

    let chosen = targetY;

    if (Math.random() < readChance) {
      // Good read — dives toward actual shot
      chosen = targetY;
    } else {
      // Pattern guess from memory
      if (memory.length >= 2) {
        // Find most-repeated quadrant in last 3 shots
        const recent = memory.slice(-3);
        const counts = {};
        recent.forEach(s => { counts[s.q] = (counts[s.q] || 0) + 1; });
        const mostCommon = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
        if (mostCommon && mostCommon[1] >= 2) {
          // Faisal repeated a corner — GK guesses that corner
          chosen = Mechanics.quadrantToY(parseInt(mostCommon[0]));
        } else {
          // No pattern — guess middle
          chosen = CONFIG.pitch.h / 2;
        }
      } else {
        // No memory yet — guess middle
        chosen = CONFIG.pitch.h / 2;
      }
    }

    k.committedY = chosen;
    k.lastReadQuadrant = quadrant;
  },

  shotQuadrant(y) {
    const goalY = CONFIG.pitch.h / 2;
    const goalH = CONFIG.goal.h;
    const isHigh = y < goalY - goalH * 0.18;
    const isLow = y > goalY + goalH * 0.18;
    if (!isHigh && !isLow) return 3;  // middle
    // We don't have X (it's always near goal x); high vs low only
    return isHigh ? 1 : 5;  // 1=top, 5=bottom (mid=3)
  },

  quadrantToY(q) {
    const goalY = CONFIG.pitch.h / 2;
    const goalH = CONFIG.goal.h;
    if (q === 1) return goalY - goalH * 0.32;  // top
    if (q === 5) return goalY + goalH * 0.32;  // bottom
    return goalY;  // middle
  },

  checkGoal(G) {
    const b = G.ball;
    const goalX = CONFIG.pitch.w - 38;
    // Only resolve once per shot
    if (b.shotResolved) return false;
    if (b.lastTouch !== 'shot' && b.lastTouch !== 'just-shot') return false;
    if (b.x + b.r < goalX) return false;
    // In goal mouth?
    const inGoal = b.y > CONFIG.pitch.h/2 - CONFIG.goal.h/2 + 8 && b.y < CONFIG.pitch.h/2 + CONFIG.goal.h/2 - 8;
    if (inGoal) {
      b.shotResolved = true;
      // Keeper save check
      if (b.shotInfo && Mechanics.keeperSaves(G, b.shotInfo)) {
        Mechanics.handleSave(G);
      } else {
        Mechanics.handleGoal(G);
      }
      return true;
    } else if (b.x > goalX + 20) {
      b.shotResolved = true;
      Mechanics.handleMiss(G);
      return true;
    }
    return false;
  },

  keeperSaves(G, info) {
    const k = G.keeper;
    const diff = CONFIG.difficulty[G.diff];
    const dy = Math.abs(G.ball.y - k.y);
    const reach = k.r + 22;

    // Difficulty-based save multiplier — Easy is more forgiving but not by huge margin
    const saveMult = G.diff === 'easy' ? 0.65 : G.diff === 'medium' ? 0.88 : 1.0;

    if (dy < reach) {
      // Direct hit on keeper — high save chance regardless of difficulty
      let sc = 0.92 - info.power * 0.20 - (info.corner ? 0.18 : 0) - Math.abs(info.curve) * 0.15;
      sc *= saveMult;
      sc = clamp(sc, 0.40, 0.95);  // floor at 0.40 — keeper always has a chance when ball comes to him
      return Math.random() < sc;
    }

    const diveSpeed = 700 * diff.keeperRead;
    const window = Math.max(0.15, info.travelTime || 0.2);
    const maxDive = diveSpeed * window;
    if (dy < reach + maxDive) {
      // Dive save
      let sc = ((reach + maxDive - dy) / (reach + maxDive)) * (G.mode === 'penalty' ? 0.65 : 0.45);
      sc -= info.power * 0.15;
      sc -= Math.abs(info.curve) * 0.18;
      sc -= info.corner ? 0.12 : 0;
      sc *= saveMult;
      sc = clamp(sc, 0.05, 0.85);
      return Math.random() < sc;
    }
    return false;
  },

  handleGoal(G) {
    G.goalsScored++;
    G.combo++;
    if (G.combo > G.bestCombo) G.bestCombo = G.combo;

    const isTopCorner = G.ball.y < CONFIG.pitch.h/2 - CONFIG.goal.h * 0.25;

    G.player.celebTime = 1.2;
    Audio.goal();
    if (isTopCorner) setTimeout(() => Audio.perfect(), 200);
    if (G.combo >= 2) setTimeout(() => Audio.combo(Math.min(5, G.combo)), 350);
    hapticPattern(isTopCorner ? [80, 40, 80, 40, 150] : [120]);

    Save.addGoal();

    // Toast
    if (isTopCorner) HUD.showToast('TOP CORNER!', 'gold', 1500);
    else if (G.combo >= 5) HUD.showToast(`${G.combo} IN A ROW!`, 'gold', 1400);
    else if (G.combo >= 3) HUD.showToast('HAT-TRICK!', 'gold', 1400);
    else HUD.showToast('GOOOAL!', 'gold', 1400);

    // Particles & shockwave
    G.shockwaves.push({ x: G.ball.x, y: G.ball.y, r: 20, age: 0, color: isTopCorner ? '#ffd33d' : '#fff' });
    G.particles.push(...makeParticles(G.ball.x, G.ball.y, '#ffd33d', isTopCorner ? 50 : 36, { speed: 350, gravity: true }));
    G.crowdHype = 1.0;
    G.timeScaleTarget = 0.4;
    setTimeout(() => { if (G.running) G.timeScaleTarget = 1; }, 600);

    checkAchievements('goal', { combo: G.combo, isTopCorner });

    if (G.mode === 'penalty') G.attemptsUsed++;

    // Mode-specific post-goal flow
    if (G.mode === 'penalty') {
      setTimeout(() => { if (G.running) Mechanics.advanceFreeKickShot(G); }, 1500);
    } else if (G.mode === 'crossing') {
      setTimeout(() => { if (G.running) Mechanics.startNextWingAttack(G); }, 1500);
    } else {
      // Arena: kickoff reset after goal
      setTimeout(() => { if (G.running) Mechanics.kickoffReset(G); }, 1500);
    }
  },

  handleSave(G) {
    G.combo = 0;
    G.keeper.diveTime = 0.9;
    G.keeper.anim = 'dive';
    Audio.save();
    hapticPattern([60, 40, 60]);
    HUD.showToast('SAVED!', 'red', 1200);
    HUD.setCoach('Keeper got it. Back to start — try again!');
    G.particles.push(...makeParticles(G.keeper.x, G.keeper.y, '#ff7e7e', 18));
    if (G.mode === 'penalty') G.attemptsUsed++;
    if (G.mode === 'penalty') {
      setTimeout(() => { if (G.running) Mechanics.advanceFreeKickShot(G); }, 1300);
    } else if (G.mode === 'crossing') {
      // Save = attack failed, but still counts as an attempt completed
      setTimeout(() => { if (G.running) Mechanics.startNextWingAttack(G); }, 1300);
    } else {
      // Arena: reset player + ball + defenders to starting positions
      setTimeout(() => { if (G.running) Mechanics.kickoffReset(G); }, 1200);
    }
  },

  handleMiss(G) {
    G.combo = 0;
    Audio.miss();
    hapticPattern([40]);
    HUD.showToast('MISSED!', 'red', 800);
    HUD.setCoach('Aim INSIDE the posts! Back to start.');
    if (G.mode === 'penalty') G.attemptsUsed++;
    if (G.mode === 'penalty') {
      setTimeout(() => { if (G.running) Mechanics.advanceFreeKickShot(G); }, 1100);
    } else if (G.mode === 'crossing') {
      setTimeout(() => { if (G.running) Mechanics.startNextWingAttack(G); }, 1100);
    } else if (G.mode === 'boss') {
      // Skills Course: missed shot = reset to start
      setTimeout(() => { if (G.running) Mechanics.resetBall(G); }, 600);
    } else {
      // Arena: reset player + ball + defenders
      setTimeout(() => { if (G.running) Mechanics.kickoffReset(G); }, 1000);
    }
  },

  // Reset player to start position (Arena kickoff or post-fail reset)
  kickoffReset(G) {
    G.player.x = 200;
    G.player.y = CONFIG.pitch.h / 2;
    G.player.vx = 0; G.player.vy = 0;
    G.player.facing = 0;
    G.enemies.forEach(e => {
      e.x = e.homeX; e.y = e.homeY;
      e.vx = 0; e.vy = 0;
      e.stun = 0;
      e.tackleCool = 0;
    });
    Mechanics.resetBall(G);
  },

  // Free Kick Studio: advance to next spot OR repeat current spot until 3 attempts on it
  advanceFreeKickShot(G) {
    const spots = G.cfg.spots;
    if (!spots) return Mechanics.resetBall(G);
    // 3 shots per spot, then advance
    G.shotsAtSpot = (G.shotsAtSpot || 0) + 1;
    if (G.shotsAtSpot >= 3) {
      G.shotsAtSpot = 0;
      G.spotIdx = (G.spotIdx || 0) + 1;
      if (G.spotIdx >= spots.length) {
        // All spots done — let endLevel decide via win condition
        G.spotIdx = spots.length - 1;
      }
    }
    Mechanics.placePlayerAtFreeKickSpot(G);
  },

  placePlayerAtFreeKickSpot(G) {
    const spots = G.cfg.spots;
    if (!spots) return;
    const spotKey = spots[G.spotIdx || 0];
    const spot = CONFIG.shotSpots[spotKey];
    if (!spot) return;
    const p = G.player;
    p.x = spot.x;
    p.y = spot.y;
    p.vx = 0; p.vy = 0;
    p.facing = 0;
    G.ball.x = spot.x + 30;
    G.ball.y = spot.y;
    G.ball.vx = 0; G.ball.vy = 0;
    G.ball.spin = 0;
    G.ball.owner = 'player';
    G.ball.lastTouch = 'player';
    G.ball.shotInfo = null;
    G.ball.shotResolved = false;
    G.ball.looseTime = 0;
    HUD.showToast(spot.label, 'gold', 1100);
  },

  // ============================================================
  // WING ATTACK — 3-phase winger play
  // Phase 1: BEAT_FULLBACK — dash past the fullback
  // Phase 2: REACH_BYLINE — get into the box / byline area
  // Phase 3: DECIDE — CROSS (PASS button) or SHOOT
  // ============================================================
  setupWingAttack(G) {
    const p = G.player;
    // Choose wing for this attack — alternates left/right for variety
    const attackIdx = G.attacksCompleted || 0;
    G.wingSide = attackIdx % 2 === 0 ? 'right' : 'left';
    const wingY = G.wingSide === 'right' ? CONFIG.pitch.h - 160 : 160;
    p.x = 380;
    p.y = wingY;
    p.vx = 0; p.vy = 0;
    p.facing = 0;
    G.ball.x = p.x + 30;
    G.ball.y = p.y;
    G.ball.vx = 0; G.ball.vy = 0;
    G.ball.spin = 0;
    G.ball.owner = 'player';
    G.ball.lastTouch = 'player';
    G.wingPhase = 'beat';
    G.wingByline = false;
    G.crossDelivered = false;

    // Spawn the FULLBACK defender — blocks the wing
    G.enemies.length = 0;
    G.enemies.push({
      x: 620, y: wingY,
      homeX: 620, homeY: wingY,
      r: 32, vx: 0, vy: 0, mode: 'fullback',
      stun: 0, animTime: 0, anim: 'stand',
      beaten: false,  // becomes true once Faisal dashes past
    });

    // Spawn teammate ready to receive cross — runs into box
    // Position 240px from goal so label has clear space and doesn't overlap goal post
    G.teammate = {
      x: 1040,
      y: G.wingSide === 'right' ? CONFIG.pitch.h / 2 - 60 : CONFIG.pitch.h / 2 + 60,
      vx: 0, vy: 0,
      baseX: 1040,
      baseY: G.wingSide === 'right' ? CONFIG.pitch.h / 2 - 60 : CONFIG.pitch.h / 2 + 60,
      r: 26,
      animTime: 0,
      runType: G.wingSide === 'right' ? 'far-post' : 'near-post',
    };

    // Cross zone is the byline region near the goal
    G.crossZone = G.wingSide === 'right'
      ? { x1: 950, y1: CONFIG.pitch.h - 280, x2: 1200, y2: CONFIG.pitch.h - 50 }
      : { x1: 950, y1: 50, x2: 1200, y2: 280 };

    HUD.showToast(G.wingSide === 'right' ? 'RIGHT WING ATTACK!' : 'LEFT WING ATTACK!', 'gold', 1200);
  },

  // Update wing attack phase based on player position vs fullback
  updateWingAttack(G, dt) {
    if (G.mode !== 'crossing') return;
    const p = G.player;
    const fullback = G.enemies[0];
    if (!fullback) return;

    // Phase transitions
    if (G.wingPhase === 'beat') {
      // Beaten the fullback if Faisal:
      //   (a) dashes past with margin, OR
      //   (b) sprints past at high speed, OR
      //   (c) is very far past the defender (>200px) — sneaky walk-around
      const past = p.x > fullback.x + 60;
      const dashing = p.dashTime > 0;
      const fast = Math.hypot(p.vx, p.vy) > 280;
      const veryFarPast = p.x > fullback.x + 200;
      if (past && !fullback.beaten && (dashing || fast || veryFarPast)) {
        fullback.beaten = true;
        G.wingPhase = 'byline';
        Audio.dash();
        HUD.showToast('BEATEN!', 'gold', 900);
        HUD.setCoach('Now run to the byline! Then CROSS or SHOOT.');
        G.particles.push(...makeParticles(p.x, p.y, '#54d9ff', 14));
      }
    }
    if (G.wingPhase === 'byline') {
      // In cross zone?
      const z = G.crossZone;
      const inZone = p.x >= z.x1 && p.x <= z.x2 && p.y >= z.y1 && p.y <= z.y2;
      if (inZone && !G.wingByline) {
        G.wingByline = true;
        Audio.star();
        HUD.showToast('IN POSITION!', 'gold', 800);
        HUD.setCoach('PASS button to CROSS, SHOOT button to score!');
      }
    }
  },

  // Fullback defender: chases Faisal, tries to tackle from side
  updateFullback(G, dt) {
    if (G.mode !== 'crossing') return;
    const p = G.player;
    const fullback = G.enemies[0];
    if (!fullback) return;
    fullback.animTime += dt;
    fullback.stun = Math.max(0, fullback.stun - dt);
    if (fullback.stun > 0) return;

    if (fullback.beaten) {
      // Has been beaten — falls behind the play, decelerates
      fullback.vx *= 0.9;
      fullback.vy *= 0.9;
      fullback.x += fullback.vx * dt;
      fullback.y += fullback.vy * dt;
      fullback.anim = Math.hypot(fullback.vx, fullback.vy) > 30 ? 'run' : 'stand';
      return;
    }

    // Block the player's path on the wing — track player tightly
    const targetX = p.x + 30;  // small lead, not too far ahead
    const targetY = p.y;
    const dx = targetX - fullback.x;
    const dy = targetY - fullback.y;
    const d = Math.hypot(dx, dy);
    const diff = CONFIG.difficulty[G.diff];
    const speed = 250 * diff.defSpeed * (1 + (G.levelIdx || 0) * 0.12);  // base bumped, +12%/level
    if (d > 12) {
      fullback.vx = lerp(fullback.vx, (dx/d) * speed, dt * 5);
      fullback.vy = lerp(fullback.vy, (dy/d) * speed, dt * 5);
    } else {
      fullback.vx *= 0.85; fullback.vy *= 0.85;
    }
    fullback.x += fullback.vx * dt;
    fullback.y += fullback.vy * dt;
    fullback.x = clamp(fullback.x, 100, 950);
    fullback.y = clamp(fullback.y, 110, CONFIG.pitch.h - 50);
    fullback.anim = Math.hypot(fullback.vx, fullback.vy) > 30 ? 'run' : 'stand';

    // Tackle: if defender is close & player isn't dashing
    if (Math.hypot(p.x - fullback.x, p.y - fullback.y) < p.r + fullback.r + 10 &&
        p.dashTime <= 0 && (fullback.tackleCool || 0) <= 0) {
      fullback.tackleCool = 1.0;
      Mechanics.tackle(G, fullback);
      // Strong push back — player must try again with dash
      p.x -= 110;
      p.vx = -50;
      HUD.setCoach('Tackle! Use DASH (yellow) to beat the fullback!');
    }
    fullback.tackleCool = Math.max(0, (fullback.tackleCool || 0) - dt);
  },

  // Cross button pressed (PASS button in wing mode)
  doWingCross(G) {
    if (G.mode !== 'crossing') return;
    if (!G.wingByline || G.crossDelivered) {
      HUD.setCoach('Get to the byline first!');
      return;
    }
    if (G.ball.owner !== 'player') return;

    // Cross to teammate — auto-curving high ball
    const t = G.teammate;
    const b = G.ball;
    G.crossDelivered = true;
    b.owner = 'none';
    b.lastTouch = 'cross';
    const dx = t.x - b.x;
    const dy = t.y - b.y;
    const d = Math.hypot(dx, dy) || 1;
    const speed = 580;
    b.vx = (dx / d) * speed;
    b.vy = (dy / d) * speed;
    b.spin = 0.2 * Math.sign(t.y - b.y) * -1;  // gentle curve toward teammate
    Audio.kick();
    HUD.showToast('CROSS!', 'gold', 700);
  },

  // Cross arrived at teammate — teammate scores via header
  resolveCrossHeader(G) {
    const t = G.teammate;
    const b = G.ball;
    if (G.mode !== 'crossing' || !G.crossDelivered) return false;
    if (b.lastTouch !== 'cross') return false;
    if (Math.hypot(b.x - t.x, b.y - t.y) > t.r + b.r + 20) return false;

    // Teammate heads it — toward goal
    const goalX = CONFIG.pitch.w - 50;
    const goalY = CONFIG.pitch.h / 2 + (Math.random() - 0.5) * CONFIG.goal.h * 0.6;
    const dx = goalX - t.x;
    const dy = goalY - t.y;
    const d = Math.hypot(dx, dy) || 1;
    b.x = t.x;
    b.y = t.y;
    b.vx = (dx / d) * 880;
    b.vy = (dy / d) * 880;
    b.spin = 0;
    b.lastTouch = 'just-shot';
    b.shotResolved = false;
    b.shotInfo = {
      power: 0.7, curve: 0,
      corner: Math.abs(goalY - CONFIG.pitch.h/2) > CONFIG.goal.h * 0.3,
      targetY: goalY,
      lane: goalY < CONFIG.pitch.h/2 - 30 ? 'high' : goalY > CONFIG.pitch.h/2 + 30 ? 'low' : 'middle',
      travelTime: d / 880,
      isHeader: true,
    };
    Mechanics.decideKeeperDive(G, goalY);
    Audio.kick();
    HUD.showToast('HEADER!', 'gold', 800);
    return true;
  },

  // Wing attack completed — start a new one
  startNextWingAttack(G) {
    G.attacksCompleted = (G.attacksCompleted || 0) + 1;
    if (G.attacksCompleted >= G.cfg.attacks) return;  // win check handles this
    Mechanics.setupWingAttack(G);
  },

  // ============================================================
  // SKILLS COURSE — dribble through numbered gates in order, then score
  // ============================================================
  setupSkillsCourse(G) {
    const p = G.player;
    p.x = 200;
    p.y = CONFIG.pitch.h / 2;
    p.vx = 0; p.vy = 0;
    p.facing = 0;
    G.ball.x = p.x + 30;
    G.ball.y = p.y;
    G.ball.vx = 0; G.ball.vy = 0;
    G.ball.spin = 0;
    G.ball.owner = 'player';
    G.ball.lastTouch = 'player';

    G.gateIdx = 0;            // current gate to collect
    G.gatesCollected = 0;
    G.coursePhase = 'gates';  // 'gates' | 'shoot'

    // Generate gate positions — winding path from left to right
    const numGates = G.cfg.gates;
    G.gates = [];
    const margin = 80;
    const minX = 320, maxX = 1080;
    // Alternate top/bottom — but keep tighter range so gates don't land near joystick on small screens
    for (let i = 0; i < numGates; i++) {
      const t = i / (numGates - 1);
      const x = minX + (maxX - minX) * t;
      // Smaller alternation: ±120 instead of ±150
      const yOffset = (i % 2 === 0) ? -120 : 120;
      const y = CONFIG.pitch.h / 2 + yOffset + (Math.random() - 0.5) * 30;
      G.gates.push({
        x, y: clamp(y, margin + 80, CONFIG.pitch.h - margin - 30),
        r: 38,
        order: i + 1,
        collected: false,
        pulse: i * 0.4,
      });
    }

    // Optional defenders (level 2 has 1, level 3 has 2)
    G.enemies.length = 0;
    const numDefs = G.cfg.defenders || 0;
    for (let i = 0; i < numDefs; i++) {
      const home = i === 0
        ? { x: 700, y: CONFIG.pitch.h / 2 - 80 }
        : { x: 900, y: CONFIG.pitch.h / 2 + 80 };
      G.enemies.push({
        x: home.x, y: home.y,
        homeX: home.x, homeY: home.y,
        r: 32, vx: 0, vy: 0, mode: 'course',
        stun: 0, animTime: 0, anim: 'stand',
        tackleCool: 0,
      });
    }
  },

  resetSkillsCourse(G) {
    // Used after tackle — reset player to start, gates remain collected
    const p = G.player;
    p.x = 200;
    p.y = CONFIG.pitch.h / 2;
    p.vx = 0; p.vy = 0;
    p.facing = 0;
    G.ball.x = p.x + 30;
    G.ball.y = p.y;
    G.ball.vx = 0; G.ball.vy = 0;
    G.ball.spin = 0;
    G.ball.owner = 'player';
    G.ball.lastTouch = 'player';
    // Reset defenders to home
    G.enemies.forEach(e => {
      e.x = e.homeX; e.y = e.homeY;
      e.vx = 0; e.vy = 0;
      e.stun = 0;
      e.tackleCool = 0;
    });
  },

  // Update gate collection — every frame, check if player reached the active gate
  updateSkillsCourse(G, dt) {
    if (G.mode !== 'boss') return;
    if (G.coursePhase !== 'gates') return;
    const p = G.player;
    const gate = G.gates[G.gateIdx];
    if (!gate) return;
    gate.pulse += dt * 3;
    // Check if player reached the gate
    if (Math.hypot(p.x - gate.x, p.y - gate.y) < gate.r + p.r) {
      gate.collected = true;
      G.gatesCollected++;
      G.gateIdx++;
      Audio.star();
      Audio.combo(Math.min(5, G.gatesCollected));
      hapticPattern([20]);
      HUD.showToast(`✓ GATE ${gate.order}`, 'gold', 600);
      G.particles.push(...makeParticles(gate.x, gate.y, '#54d9ff', 14));
      G.shockwaves.push({ x: gate.x, y: gate.y, r: gate.r, age: 0, color: '#54d9ff' });
      // If all gates collected, transition to shoot phase
      if (G.gateIdx >= G.gates.length) {
        G.coursePhase = 'shoot';
        HUD.showToast('🎯 NOW SHOOT!', 'gold', 1500);
        HUD.setCoach('All gates collected! Run to the goal and SHOOT!');
        G.timeScaleTarget = 0.5;
        setTimeout(() => { if (G.running) G.timeScaleTarget = 1; }, 600);
      } else {
        const nextGate = G.gates[G.gateIdx];
        HUD.setCoach(`Gate ${nextGate.order} next!`);
      }
    }
  },

  // Update defenders in skills course — they chase player
  updateSkillsCourseDefenders(G, dt) {
    if (G.mode !== 'boss') return;
    G.enemies.forEach(e => {
      e.animTime += dt;
      e.stun = Math.max(0, e.stun - dt);
      e.tackleCool = Math.max(0, (e.tackleCool || 0) - dt);
      if (e.stun > 0) { e.anim = 'stand'; return; }
      const p = G.player;
      // Track player tightly
      const targetX = p.x;
      const targetY = p.y;
      const dx = targetX - e.x;
      const dy = targetY - e.y;
      const d = Math.hypot(dx, dy);
      const diff = CONFIG.difficulty[G.diff];
      const speed = 230 * diff.defSpeed * (1 + (G.levelIdx || 0) * 0.12);
      if (d > 14) {
        e.vx = lerp(e.vx, (dx/d) * speed, dt * 4);
        e.vy = lerp(e.vy, (dy/d) * speed, dt * 4);
      } else {
        e.vx *= 0.85; e.vy *= 0.85;
      }
      e.x += e.vx * dt;
      e.y += e.vy * dt;
      e.x = clamp(e.x, 100, CONFIG.pitch.w - 100);
      e.y = clamp(e.y, 110, CONFIG.pitch.h - 50);
      e.anim = Math.hypot(e.vx, e.vy) > 30 ? 'run' : 'stand';
      // Tackle if close
      if (G.ball.owner === 'player' && Math.hypot(p.x - e.x, p.y - e.y) < p.r + e.r &&
          p.dashTime <= 0 && e.tackleCool <= 0) {
        e.tackleCool = 1.5;
        // Reset to start position (course rule: lose ball = back to start)
        Audio.hit();
        hapticPattern([60, 40, 60]);
        HUD.showToast('CAUGHT!', 'red', 700);
        HUD.setCoach('Defender stole the ball! Back to start. Try DASH!');
        G.particles.push(...makeParticles(p.x, p.y, '#ff7e7e', 14));
        setTimeout(() => { if (G.running) Mechanics.resetSkillsCourse(G); }, 700);
      }
    });
  },

  doDash(G) {
    const p = G.player;
    if (p.dashTime > 0 || p.dashCool > 0) return;
    p.dashTime = CONFIG.player.dashDuration;
    p.dashCool = CONFIG.player.dashCooldown;
    Audio.dash();
    hapticPattern([15]);
    G.particles.push(...makeParticles(p.x, p.y, '#54d9ff', 8));
  },

  doFeint(G) {
    if (G.mode === 'crossing') {
      // PASS button = CROSS in Wing Attack
      Mechanics.doWingCross(G);
      return;
    }
    // Street 1v1 uses joystick patterns for skill moves, not the FEINT button.
    // For other modes, FEINT does nothing.
  },
};

// ============================================================
// COMMON DRAW HELPERS
// ============================================================
function drawBall(G) {
  const b = G.ball;
  drawShadow(b.x, b.y + 12, 10, 4);
  // Spin trail
  if (b.owner !== 'player' && Math.hypot(b.vx, b.vy) > 100) {
    ctx.fillStyle = `rgba(255,255,255,0.3)`;
    for (let i = 1; i <= 4; i++) {
      ctx.globalAlpha = 0.3 - i * 0.06;
      ctx.beginPath();
      ctx.arc(b.x - b.vx * 0.015 * i, b.y - b.vy * 0.015 * i, b.r * (1 - i * 0.1), 0, Math.PI*2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
  // Ball
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(b.x, b.y, b.r, 0, Math.PI*2);
  ctx.fill();
  ctx.strokeStyle = '#0c1a14';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  // Pentagons
  ctx.fillStyle = '#0c1a14';
  const rot = (b.x + b.y) / 30;
  for (let i = 0; i < 5; i++) {
    const a = rot + i * Math.PI * 2 / 5 - Math.PI / 2;
    if (Math.cos(a) > -0.5) {
      ctx.beginPath();
      ctx.arc(b.x + Math.cos(a) * b.r * 0.5, b.y + Math.sin(a) * b.r * 0.5, b.r * 0.18, 0, Math.PI*2);
      ctx.fill();
    }
  }
}

function drawPlayer(G) {
  const p = G.player;
  drawShadow(p.x, p.y + 28, 22, 7);

  // Dash trail
  if (p.dashTime > 0) {
    for (let i = 1; i <= 4; i++) {
      ctx.fillStyle = `rgba(84, 217, 255, ${(p.dashTime / 0.45) * (0.4 / i)})`;
      ctx.beginPath();
      ctx.arc(p.x - i * 14, p.y - 5, 22 - i * 3, 0, Math.PI*2);
      ctx.fill();
    }
  }

  // Hit flash
  if (p.hitTime > 0) {
    ctx.fillStyle = `rgba(255, 80, 80, ${p.hitTime})`;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 38, 0, Math.PI*2);
    ctx.fill();
  }

  // Feint aura
  if (p.feintTime > 0) {
    const t = p.feintTime / CONFIG.player.feintDuration;
    ctx.fillStyle = `rgba(167, 139, 250, ${t * 0.4})`;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 50, 0, Math.PI*2);
    ctx.fill();
    ctx.strokeStyle = `rgba(167, 139, 250, ${t * 0.9})`;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 30 + (1 - t) * 40, 0, Math.PI*2);
    ctx.stroke();
  }

  // Charge ring
  if (G.charge.active) {
    ctx.strokeStyle = `rgba(255, 211, 61, ${0.4 + G.charge.power * 0.5})`;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 35 + G.charge.power * 6, 0, Math.PI*2);
    ctx.stroke();
  }

  // Sprite — frame selection
  // CRITICAL: IDLE (0), RUN1 (1), and KICK (3) all have a ball baked in.
  // Only RUN2 (2) and CELEBRATE (4) are ball-free. Use only those.
  const moving = Math.hypot(p.vx, p.vy) > 30;
  let frame;
  if (p.celebTime > 0) frame = FRAME_PLAYER.CELEBRATE;
  else frame = FRAME_PLAYER.RUN2;  // always RUN2 for movement and standing
  // Bigger sprite for visibility (was 70×90 → 96×120)
  const flip = Math.cos(p.facing) < 0;
  drawSprite(SPRITES.player, frame, 5, p.x, p.y + 44, 150, 188, flip);
}

function drawGates(G, t) {
  if (!G.gates) return;
  const time = t / 1000;
  G.gates.forEach((gate, idx) => {
    const isActive = idx === G.gateIdx && !gate.collected;
    const isPast = idx < G.gateIdx;
    const isFuture = idx > G.gateIdx;

    if (gate.collected) {
      // Collected — dim faded checkmark
      ctx.save();
      ctx.globalAlpha = 0.35;
      ctx.strokeStyle = '#54d9ff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(gate.x, gate.y, gate.r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = '#54d9ff';
      ctx.font = 'bold 28px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('✓', gate.x, gate.y);
      ctx.restore();
    } else if (isActive) {
      // Active — bright pulsing blue ring with big number
      const pulse = 1 + Math.sin(time * 4) * 0.12;
      ctx.save();
      // Outer glow
      ctx.shadowColor = '#54d9ff';
      ctx.shadowBlur = 30;
      ctx.strokeStyle = '#54d9ff';
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.arc(gate.x, gate.y, gate.r * pulse, 0, Math.PI * 2);
      ctx.stroke();
      // Inner ring
      ctx.shadowBlur = 0;
      ctx.strokeStyle = '#a3e8ff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(gate.x, gate.y, gate.r * pulse - 8, 0, Math.PI * 2);
      ctx.stroke();
      // Big number
      ctx.fillStyle = '#fff';
      ctx.shadowColor = '#54d9ff';
      ctx.shadowBlur = 12;
      ctx.font = 'bold 40px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(gate.order, gate.x, gate.y);
      ctx.restore();
    } else if (isFuture) {
      // Future — faded gold ring with number
      ctx.save();
      ctx.globalAlpha = 0.55;
      ctx.strokeStyle = '#ffd33d';
      ctx.lineWidth = 4;
      ctx.setLineDash([6, 8]);
      ctx.beginPath();
      ctx.arc(gate.x, gate.y, gate.r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#ffd33d';
      ctx.font = 'bold 32px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(gate.order, gate.x, gate.y);
      ctx.restore();
    }
  });
}

function drawKeeper(G) {
  const k = G.keeper;
  drawShadow(k.x, k.y + 28, 22, 7);
  let frame = FRAME_OPP.GK_READY;
  if (k.diveTime > 0 || k.anim === 'dive') frame = FRAME_OPP.GK_DIVE;
  // GK is on right side of pitch, must face left toward player (flip = true)
  drawSprite(SPRITES.opp, frame, 4, k.x, k.y + 32, 122, 156, true);
  // Glove indicator
  if (k.diveTime > 0) {
    ctx.fillStyle = 'rgba(255, 211, 61, 0.4)';
    ctx.beginPath();
    ctx.arc(k.x, k.y, 36, 0, Math.PI*2);
    ctx.fill();
  }
}

function drawEnemy(G, e) {
  drawShadow(e.x, e.y + 38, 28, 9);
  if (e.mode === 'boss') {
    // Boss aura
    ctx.fillStyle = e.feintConfusion > 0 ? 'rgba(167, 139, 250, 0.3)' : 'rgba(255, 100, 100, 0.2)';
    ctx.beginPath();
    ctx.arc(e.x, e.y, 56, 0, Math.PI*2);
    ctx.fill();
  }
  const frame = e.anim === 'run' ? FRAME_OPP.DEF_RUN : FRAME_OPP.DEF_STAND;
  // Defender ALWAYS faces the player (not based on instantaneous velocity)
  const flip = e.x > G.player.x;
  // Bigger sprite (was 64×84 → 86×112)
  drawSprite(SPRITES.opp, frame, 4, e.x, e.y + 44, 138, 178, flip);
}

function drawShockwaves(G, dt) {
  G.shockwaves = G.shockwaves.filter((s) => {
    s.age += dt;
    s.r += dt * 600;
    if (s.age >= 1) return false;
    const alpha = (1 - s.age) * 0.6;
    ctx.strokeStyle = s.color;
    ctx.globalAlpha = alpha;
    ctx.lineWidth = 8 * (1 - s.age);
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
    ctx.stroke();
    ctx.globalAlpha = 1;
    return true;
  });
}

function drawCountdown(G) {
  if (G.countdown <= 0) return;
  const num = Math.ceil(G.countdown);
  const frac = num - G.countdown;
  ctx.save();
  ctx.fillStyle = `rgba(0,0,0,${0.4 * (1 - frac)})`;
  ctx.fillRect(0, 0, CONFIG.pitch.w, CONFIG.pitch.h);
  ctx.fillStyle = num === 0 ? '#22d36c' : '#ffd33d';
  ctx.font = `bold ${100 + frac * 40}px sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.globalAlpha = 1 - frac;
  ctx.fillText(num > 0 ? String(num) : 'GO!', CONFIG.pitch.w / 2, CONFIG.pitch.h / 2);
  ctx.restore();
}

function drawAimGuide(G) {
  if (!G.charge.active) return;
  const b = G.ball;
  const charge = G.charge;
  let target;
  if (G.mode === 'crossing' && G.teammate) {
    target = G.teammate;
  } else {
    target = { x: CONFIG.pitch.w - 50, y: CONFIG.pitch.h/2 + charge.aimY * (CONFIG.goal.h * 0.45) };
  }

  // Predict auto-curve magnitude
  const goalCenterY = CONFIG.pitch.h / 2;
  const offsetFromCenter = b.y - goalCenterY;
  const distFromGoal = (CONFIG.pitch.w - 50) - b.x;
  const distFactor = clamp(distFromGoal / 600, 0, 1);
  const wingFactor = clamp(Math.abs(offsetFromCenter) / 200, 0, 1);
  const autoCurve = -Math.sign(offsetFromCenter) * 0.7 * distFactor * wingFactor;

  const power = charge.power;
  // Power-based color: blue→gold→red as power builds
  const r = power > 0.5 ? Math.round(255) : Math.round(84 + (255-84) * power * 2);
  const g = power > 0.5 ? Math.round(211 - (power-0.5) * 320) : Math.round(217 - (power) * 12);
  const bb = power > 0.5 ? Math.round(61 - (power-0.5) * 122) : Math.round(255 - power * 88);
  ctx.strokeStyle = `rgba(${clamp(r,0,255)},${clamp(g,0,255)},${clamp(Math.max(0,bb),0,255)},${0.7 + power * 0.3})`;
  ctx.lineWidth = 3 + power * 2;
  ctx.setLineDash([10, 6]);
  ctx.lineDashOffset = -performance.now() / 40;
  ctx.beginPath();
  ctx.moveTo(b.x, b.y);

  if (Math.abs(autoCurve) > 0.05) {
    const dx = target.x - b.x;
    const dy = target.y - b.y;
    const len = Math.hypot(dx, dy);
    const perpX = -dy / len;
    const perpY = dx / len;
    const bendStrength = 90 * autoCurve;
    const midX = (b.x + target.x) / 2 + perpX * bendStrength;
    const midY = (b.y + target.y) / 2 + perpY * bendStrength;
    ctx.quadraticCurveTo(midX, midY, target.x, target.y);
  } else {
    ctx.lineTo(target.x, target.y);
  }
  ctx.stroke();
  ctx.setLineDash([]);

  // Reticle
  const pulse = Math.sin(performance.now() / 100) * 3 + 14;
  ctx.strokeStyle = '#ffd33d';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(target.x, target.y, pulse, 0, Math.PI*2);
  ctx.stroke();

  // Power bar BELOW ball
  if (power > 0.05) {
    const powerW = 100;
    const powerH = 9;
    const py = b.y + 38;
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    roundRect(ctx, b.x - powerW/2, py, powerW, powerH, 4, true, false);
    ctx.fillStyle = power > 0.75 ? '#ff4d4d' : (power > 0.45 ? '#ffd33d' : '#54d9ff');
    roundRect(ctx, b.x - powerW/2, py, powerW * power, powerH, 4, true, false);

    // Power text
    const powerTxt = power > 0.75 ? 'BIG POWER' : power > 0.45 ? 'MEDIUM' : 'SOFT';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(powerTxt, b.x, py + powerH + 8);
  }
}

// ============================================================
// GAME SCENE — base for arena/penalty/crossing/boss
// ============================================================
function makeGameScene(mode) {
  return {
    G: null,

    enter(params) {
      this.G = makeGameState(mode, params.level || 0);
      this.setup();
      $('home').classList.remove('active');
      $('game').classList.add('active');
      // Show "CROSS" button in crossing mode (uses feint button slot, relabeled)
      HUD.showFeintBtn(mode === 'crossing');
      HUD.setFeintLabel(mode === 'crossing' ? 'CROSS' : 'FEINT');
      // Initial HUD
      this.refreshHUD();
      HUD.setCoach(this.G.cfg.coach);
      Audio.startAmbient();
      resizeCanvas();  // ensure layout fresh
    },

    exit() {
      $('game').classList.remove('active');
      Audio.stopAmbient();
      this.G = null;
    },

    setup() {
      const G = this.G;

      // Mode-specific setup
      if (mode === 'penalty') {
        // Free Kick Studio: start at first spot
        G.spotIdx = 0;
        G.shotsAtSpot = 0;
        Mechanics.placePlayerAtFreeKickSpot(G);
      } else if (mode === 'crossing') {
        // WING ATTACK: 3-phase active play
        // Phase 1: BEAT the fullback (Faisal must dash past)
        // Phase 2: REACH the byline (cross zone)
        // Phase 3: CHOOSE — cross or shoot
        Mechanics.setupWingAttack(G);
      } else if (mode === 'boss') {
        // SKILLS COURSE — dribble through gates, then score
        Mechanics.setupSkillsCourse(G);
      } else {
        // Arena: spread defenders
        const defs = G.cfg.defenders || 2;
        for (let i = 0; i < defs; i++) {
          G.enemies.push({
            x: 540 + (i % 3) * 180,
            y: 180 + Math.floor(i / 3) * 180 + (i % 2) * 70,
            homeX: 540 + (i % 3) * 180,
            homeY: 180 + Math.floor(i / 3) * 180 + (i % 2) * 70,
            r: 30, vx: 0, vy: 0, mode: 'def',
            stun: 0, animTime: 0, anim: 'stand',
          });
        }
      }
    },

    update(dt) {
      const G = this.G;
      if (!G || !G.running) return;

      // Slow-mo handling
      G.timeScale = lerp(G.timeScale, G.timeScaleTarget, dt * 6);
      const sdt = dt * G.timeScale;

      if (G.paused) return;

      // Countdown
      if (G.countdown > 0) {
        const prev = Math.ceil(G.countdown);
        G.countdown -= dt;
        const cur = Math.ceil(G.countdown);
        if (cur !== prev && cur >= 0) Audio.countdown();
        if (G.countdown <= 0) Audio.whistle();
        return;
      }

      // Time
      if (G.cfg.time && G.cfg.time > 0) {
        G.timeLeft -= sdt;
        if (G.timeLeft <= 0) { G.timeLeft = 0; this.endLevel(G.goalsScored >= G.cfg.goals); return; }
      }

      // Crowd hype decay
      G.crowdHype *= 0.985;

      // Update entities
      Mechanics.updatePlayer(G, sdt);
      Mechanics.updateBall(G, sdt);
      Mechanics.updateKeeper(G, sdt);

      // Mode-specific updates BEFORE generic enemy update (some modes own their own defender logic)
      if (mode === 'crossing') {
        Mechanics.updateWingAttack(G, sdt);
        Mechanics.updateFullback(G, sdt);
        this.updateTeammate(sdt);
        // Resolve cross delivery
        if (G.crossDelivered && G.ball.lastTouch === 'cross') {
          Mechanics.resolveCrossHeader(G);
        }
      } else if (mode === 'boss') {
        // Skills Course: collect gates, then shoot
        Mechanics.updateSkillsCourse(G, sdt);
        Mechanics.updateSkillsCourseDefenders(G, sdt);
      } else {
        Mechanics.updateEnemies(G, sdt);
      }

      // Check goal — Skills Course needs goal check during shoot phase
      Mechanics.checkGoal(G);

      // Particles
      G.particles = updateParticles(G.particles, sdt);

      // Win condition
      this.checkWin();

      // Energy fail
      if (G.energy <= 0) this.endLevel(false);

      // HUD refresh
      this.refreshHUD();
    },

    updateTeammate(dt) {
      const G = this.G;
      const t = G.teammate;
      if (!t) return;
      t.animTime += dt;
      // Hold position with subtle bob — waiting for cross
      t.y = lerp(t.y, t.baseY + Math.sin(t.animTime * 1.5) * 6, dt * 2);
    },

    checkWin() {
      const G = this.G;
      const cfg = G.cfg;
      if (mode === 'arena' && G.goalsScored >= cfg.goals) this.endLevel(true);
      if (mode === 'penalty') {
        if (G.attemptsUsed >= cfg.shots) {
          this.endLevel(G.goalsScored >= cfg.goals);
        }
      }
      // WING ATTACK: complete N attacks (each attack = beat fullback + reach byline + cross/shoot)
      if (mode === 'crossing') {
        if ((G.attacksCompleted || 0) >= cfg.attacks) this.endLevel(true);
        // Time-out failure
        if (cfg.time > 0 && G.timeLeft <= 0) this.endLevel(false);
      }
      // SKILLS COURSE: collect all gates, then score
      if (mode === 'boss') {
        // Win = all gates collected AND a goal scored after entering shoot phase
        if (G.coursePhase === 'shoot' && G.goalsScored > 0) this.endLevel(true);
        // Time-out failure
        if (cfg.time > 0 && G.timeLeft <= 0) this.endLevel(false);
      }
    },

    refreshHUD() {
      const G = this.G;
      const cfg = G.cfg;
      const modeNames = { arena: 'STAR ARENA', penalty: 'FREE KICK', crossing: 'WING ATTACK', boss: 'SKILLS COURSE' };

      // Scoreboard right side — prioritize mode-specific metric
      let awayLabel = 'TIME', awayValue = '';
      if (cfg.shots) {
        awayLabel = 'SHOTS';
        awayValue = cfg.shots - G.attemptsUsed;
      } else if (cfg.attacks) {
        awayLabel = 'ATTACKS';
        awayValue = `${G.attacksCompleted || 0}/${cfg.attacks}`;
      } else if (cfg.gates) {
        awayLabel = 'GATES';
        if (G.coursePhase === 'shoot') {
          awayValue = '🎯';  // shoot phase indicator
        } else {
          awayValue = `${G.gatesCollected || 0}/${cfg.gates}`;
        }
      } else if (cfg.time === 0) {
        awayLabel = 'FREE'; awayValue = '∞';
      } else if (cfg.time) {
        const m = Math.floor(G.timeLeft / 60);
        const s = Math.floor(G.timeLeft % 60).toString().padStart(2, '0');
        awayValue = `${m}:${s}`;
        HUD.setTimeStyle(G.timeLeft);
      }
      HUD.setScoreboard(G.goalsScored, awayValue, awayLabel, modeNames[mode], `LV ${G.levelIdx + 1}`);

      // Mission banner
      if (mode === 'arena') {
        HUD.setMission(`⚽ ${G.goalsScored}/${cfg.goals}`, G.goalsScored < cfg.goals ? `${cfg.goals - G.goalsScored} more goal${cfg.goals - G.goalsScored > 1 ? 's' : ''}!` : 'WIN!');
      } else if (mode === 'penalty') {
        const spotKey = (cfg.spots && cfg.spots[G.spotIdx || 0]) || '';
        const spot = CONFIG.shotSpots[spotKey];
        const spotLabel = spot ? spot.dist : '';
        HUD.setMission(`⚽ ${G.goalsScored}/${cfg.goals} • ${spotLabel}`, `${cfg.shots - G.attemptsUsed} shots left`);
      } else if (mode === 'crossing') {
        // Phase-aware coaching
        let phaseHint = 'DASH past the fullback!';
        if (G.wingPhase === 'byline') phaseHint = G.wingByline ? 'CROSS or SHOOT!' : 'Run to the byline!';
        HUD.setMission(`🎯 ${G.attacksCompleted || 0}/${cfg.attacks}`, phaseHint);
      } else if (mode === 'boss') {
        // Skills Course mission text
        if (G.coursePhase === 'shoot') {
          HUD.setMission('🎯 SHOOT NOW!', 'All gates done. Run to goal & SHOOT!');
        } else {
          const collected = G.gatesCollected || 0;
          const total = cfg.gates;
          const nextGate = G.gates && G.gates[G.gateIdx];
          const hint = nextGate
            ? `Run through gate ${nextGate.order} (blue glow)`
            : 'Collect all gates in order!';
          HUD.setMission(`🚩 ${collected}/${total}`, hint);
        }
      }

      HUD.setEnergy(G.energy);
      HUD.setCombo(G.combo);
    },

    draw() {
      const G = this.G;
      if (!G) return;
      const t = performance.now();

      // Clear (set transform back to identity for clear, then reapply)
      ctx.setTransform(view.dpr, 0, 0, view.dpr, 0, 0);
      ctx.fillStyle = '#0c1a14';
      ctx.fillRect(0, 0, view.screenW, view.screenH);

      applyView();

      drawPitch(t);
      // Skills Course needs the goal (kid shoots after collecting gates)
      drawGoal();
      this.drawModeOverlay(t);
      drawShockwaves(G, 1/60);

      // Draw skills-course gates BEFORE players (so players appear over them)
      if (mode === 'boss' && G.gates) drawGates(G, t);

      drawAimGuide(G);

      // Draw entities (sorted by Y for depth)
      const drawables = [];
      drawables.push({ y: G.ball.y, fn: () => drawBall(G) });
      drawables.push({ y: G.player.y, fn: () => drawPlayer(G) });
      drawables.push({ y: G.keeper.y, fn: () => drawKeeper(G) });
      G.enemies.forEach(e => drawables.push({ y: e.y, fn: () => drawEnemy(G, e) }));
      if (G.teammate) drawables.push({ y: G.teammate.y, fn: () => this.drawTeammate(t) });
      drawables.sort((a, b) => a.y - b.y);
      drawables.forEach(d => d.fn());

      drawParticles(G.particles);

      // Countdown overlay
      drawCountdown(G);
    },

    drawModeOverlay(t) {
      const G = this.G;
      if (mode === 'penalty') {
        // Draw penalty target zones
        const goalX = CONFIG.pitch.w - 50;
        const goalY = CONFIG.pitch.h / 2;
        const gh = CONFIG.goal.h;
        ['high', 'middle', 'low'].forEach((lane, i) => {
          const y = goalY + (i - 1) * gh * 0.32;
          ctx.fillStyle = lane === 'middle' ? 'rgba(255,255,255,0.05)' : 'rgba(255, 211, 61, 0.1)';
          ctx.fillRect(goalX - 10, y - 30, 50, 60);
        });
      }
      // WING ATTACK overlay: phase-aware visualization
      if (mode === 'crossing') {
        // Phase 1: highlight fullback as obstacle to beat
        if (G.wingPhase === 'beat') {
          const fb = G.enemies[0];
          if (fb && !fb.beaten) {
            const pulse = 0.2 + Math.sin(t / 300) * 0.08;
            ctx.fillStyle = `rgba(255, 100, 100, ${pulse})`;
            ctx.beginPath();
            ctx.arc(fb.x, fb.y, fb.r + 12, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = 'rgba(255, 100, 100, 0.95)';
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('DASH PAST!', fb.x, fb.y - 60);
          }
        }
        // Phase 2: cross zone visible
        if (G.wingPhase === 'byline' && G.crossZone) {
          const z = G.crossZone;
          const inZone = G.player.x >= z.x1 && G.player.x <= z.x2 && G.player.y >= z.y1 && G.player.y <= z.y2;
          const pulse = 0.15 + Math.sin(t / 500) * 0.05;
          ctx.fillStyle = inZone ? `rgba(34, 211, 108, ${pulse + 0.1})` : `rgba(84, 217, 255, ${pulse})`;
          ctx.fillRect(z.x1, z.y1, z.x2 - z.x1, z.y2 - z.y1);
          ctx.strokeStyle = inZone ? '#22d36c' : '#54d9ff';
          ctx.lineWidth = 4;
          ctx.setLineDash([14, 10]);
          ctx.lineDashOffset = -t / 60;
          ctx.strokeRect(z.x1, z.y1, z.x2 - z.x1, z.y2 - z.y1);
          ctx.setLineDash([]);
          // Label
          ctx.fillStyle = inZone ? '#22d36c' : '#54d9ff';
          roundRect(ctx, (z.x1 + z.x2) / 2 - 90, z.y1 + 8, 180, 26, 12);
          ctx.fillStyle = '#0c1a14';
          ctx.font = 'bold 13px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(inZone ? '✅ CROSS or SHOOT!' : '🏃 RUN TO BYLINE', (z.x1 + z.x2) / 2, z.y1 + 21);
        }
      }
      // SKILLS COURSE: arrow pointing from player to next gate
      if (mode === 'boss') {
        if (G.coursePhase === 'gates' && G.gates) {
          const nextGate = G.gates[G.gateIdx];
          if (nextGate) {
            const dx = nextGate.x - G.player.x;
            const dy = nextGate.y - G.player.y;
            const dist = Math.hypot(dx, dy);
            if (dist > 80) {  // only show arrow when far
              const ang = Math.atan2(dy, dx);
              const ax = G.player.x + Math.cos(ang) * 60;
              const ay = G.player.y + Math.sin(ang) * 60 - 30;
              ctx.save();
              ctx.translate(ax, ay);
              ctx.rotate(ang);
              ctx.fillStyle = 'rgba(84, 217, 255, 0.85)';
              ctx.shadowColor = '#54d9ff';
              ctx.shadowBlur = 10;
              ctx.beginPath();
              ctx.moveTo(20, 0);
              ctx.lineTo(0, -10);
              ctx.lineTo(0, -3);
              ctx.lineTo(-15, -3);
              ctx.lineTo(-15, 3);
              ctx.lineTo(0, 3);
              ctx.lineTo(0, 10);
              ctx.closePath();
              ctx.fill();
              ctx.restore();
            }
          }
        }
      }
    },

    drawTeammate(t) {
      const G = this.G;
      const tm = G.teammate;
      if (!tm) return;
      drawShadow(tm.x, tm.y + 30, 22, 7);
      // Indicator ring — pulsing blue when waiting for cross
      const ready = G.wingByline && !G.crossDelivered;
      const color = ready ? '#54d9ff' : '#ffd33d';
      ctx.strokeStyle = color;
      ctx.lineWidth = 4;
      ctx.setLineDash([10, 6]);
      ctx.lineDashOffset = -t / 80;
      ctx.beginPath();
      ctx.arc(tm.x, tm.y, 36 + Math.sin(t / 200) * 3, 0, Math.PI*2);
      ctx.stroke();
      ctx.setLineDash([]);
      // Label — bigger for readability on small screens
      ctx.fillStyle = color;
      roundRect(ctx, tm.x - 70, tm.y - 65, 140, 28, 14);
      ctx.fillStyle = '#0c1a14';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(ready ? '⚽ CROSS NOW' : 'PASS HERE', tm.x, tm.y - 51);
      // Sprite — bigger to match new sizes
      const frame = FRAME_PLAYER.RUN2;
      drawSprite(SPRITES.player, frame, 5, tm.x, tm.y + 36, 124, 156, true);
    },

    onShootDown() {
      Mechanics.startCharge(this.G);
    },
    onShootUp() {
      Mechanics.releaseCharge(this.G);
    },
    onDash() {
      Mechanics.doDash(this.G);
    },
    onFeint() {
      Mechanics.doFeint(this.G);
    },

    onPause() {
      this.G.paused = !this.G.paused;
      $('pauseOverlay').hidden = !this.G.paused;
    },

    endLevel(won) {
      const G = this.G;
      G.running = false;
      if (won) Audio.whistle();

      // Calculate stars
      let stars = 0;
      if (won) {
        stars = 1;
        if (G.energy >= CONFIG.stars.goodEnergyMin) stars = 2;
        if (G.energy >= CONFIG.stars.perfectEnergyMin && (!G.cfg.time || G.timeLeft > G.cfg.time * CONFIG.stars.perfectTimeMin)) stars = 3;
        Save.addLevelComplete(mode, G.levelIdx, stars);
        checkAchievements('level', { stars, mode, diff: G.diff });
      }

      const isLast = G.levelIdx >= CONFIG.levels[mode].length - 1;
      const starsHTML = [0,1,2].map(i => `<span class="star ${i < stars ? 'earned' : ''}">★</span>`).join('');

      // Mode-specific primary metric
      let primaryNum, primaryLabel, secondaryHTML = '';
      if (mode === 'crossing') {
        primaryNum = G.attacksCompleted || 0;
        primaryLabel = 'ATTACKS';
      } else if (mode === 'boss') {
        // Skills Course: show "5/5 GATES" and goal indicator separately
        primaryNum = `${G.gatesCollected || 0}/${G.cfg.gates}`;
        primaryLabel = 'GATES';
        if (G.goalsScored > 0) {
          secondaryHTML = '<div class="result-badge">⚽ GOAL SCORED!</div>';
        }
      } else if (mode === 'penalty') {
        primaryNum = G.goalsScored;
        primaryLabel = `GOALS (${G.attemptsUsed} kicks)`;
      } else {
        primaryNum = G.goalsScored;
        primaryLabel = 'GOALS';
      }

      // Fail icon depends on reason
      const failIcon = (G.cfg.time && G.timeLeft <= 0) ? '⏱' : '😔';

      setTimeout(() => {
        showModal(`
          <div class="modal-icon">${won ? '🏆' : failIcon}</div>
          <h2>${won ? G.cfg.name + (isLast ? ' COMPLETE!' : ' WON!') : (G.cfg.time && G.timeLeft <= 0 ? 'TIME UP!' : 'TRY AGAIN!')}</h2>
          ${won ? `<div class="modal-stars">${starsHTML}</div>` : ''}
          <div class="result-stats">
            <div class="result-stat"><div class="result-num">${primaryNum}</div><div class="result-label">${primaryLabel}</div></div>
            <div class="result-stat"><div class="result-num">x${G.bestCombo}</div><div class="result-label">BEST</div></div>
            <div class="result-stat"><div class="result-num">${Math.round(G.energy)}%</div><div class="result-label">ENERGY</div></div>
          </div>
          ${secondaryHTML}
          ${won ? (stars === 3 ? '<p>⭐ Perfect performance!</p>' : stars === 2 ? '<p>👍 Great work!</p>' : '<p>✓ You did it!</p>') : '<p>Try again!</p>'}
          ${won && !isLast ? '<button class="btn-primary" id="mNext">▶ NEXT LEVEL</button>' : ''}
          ${won && isLast ? '<button class="btn-primary" id="mHome">BACK TO MENU</button>' : ''}
          <button class="btn-secondary" id="mReplay">${won ? 'REPLAY' : 'TRY AGAIN'}</button>
          <button class="btn-secondary" id="mExit">EXIT TO MENU</button>
        `);
        const next = $('mNext'), replay = $('mReplay'), exitB = $('mExit'), home = $('mHome');
        if (next) next.onclick = () => { hideModal(); Scene.switch(mode + '-game', { level: G.levelIdx + 1 }); };
        if (home) home.onclick = () => { hideModal(); Scene.switch('home'); };
        replay.onclick = () => { hideModal(); Scene.switch(mode + '-game', { level: G.levelIdx }); };
        exitB.onclick = () => { hideModal(); Scene.switch('home'); };
      }, 1100);
    },
  };
}

// Register all 4 game scenes
['arena', 'penalty', 'crossing', 'boss'].forEach((mode) => {
  Scene.register(mode + '-game', makeGameScene(mode));
});

// Pause / exit handlers
$('exitBtn').addEventListener('click', () => {
  Audio.buttonTap();
  if (Scene.current && Scene.current.G) {
    Scene.current.G.paused = true;
    $('pauseOverlay').hidden = false;
  }
});
$('resumeBtn').addEventListener('click', () => {
  Audio.buttonTap();
  if (Scene.current && Scene.current.G) Scene.current.G.paused = false;
  $('pauseOverlay').hidden = true;
});
$('quitBtn').addEventListener('click', () => {
  Audio.buttonTap();
  $('pauseOverlay').hidden = true;
  Scene.switch('home');
});

// ============================================================
// LEVEL LAUNCH
// ============================================================
function startLevel(mode, level = 0) {
  Audio.init();
  Scene.switch(mode + '-game', { level });
}

// ============================================================
// BOOT
// ============================================================
let assetsLoaded = 0;
function checkAssets() {
  assetsLoaded++;
  $('loaderFill').style.width = (assetsLoaded / 2 * 100) + '%';
  if (assetsLoaded >= 2) boot();
}
SPRITES.player.onload = checkAssets;
SPRITES.opp.onload = checkAssets;
SPRITES.player.onerror = checkAssets;
SPRITES.opp.onerror = checkAssets;
setTimeout(() => { if (assetsLoaded < 2) boot(); }, 2500);

function boot() {
  setTimeout(() => $('loader').classList.add('fade-out'), 200);
  setTimeout(() => { $('loader').remove(); }, 800);
  resizeCanvas();
  Scene.switch('home');
  // Show first-launch help
  if (!localStorage.getItem(SAVE_KEY)) {
    setTimeout(() => showHelp(), 600);
  }
}

// Expose for debugging
window.F17 = { Scene, Save, Audio, CONFIG, Mechanics, Input, HUD };
